// 변수 선언, 참조변수
// let heading = document.querySelector('#heading');
// heading.onclick = function() {
//   heading.style.color="red";
// }

// <!-- ###강사님 페이지### -->
// let name = prompt("이름을 입력하세요!");
// document.write("<h2>" + name + "님, 환영합니다! <h2/>" );

// #### 오후 첫시간 예시
// let age = prompt("당신의 나이를 알려주세요!", "0");
// if (age >= 20) {
//   document.write("😋당신은 성인입니다!");
// } else {
//   document.write("😫😐당신은 미성년자 입니다!");
// }

// 주의사항 - 대소문자 구분, 들여쓰기 잘하기
/* 여러줄 주석 */ 
// 한줄주석

// let sum = 10; 
/* 변수의 규칙을 지켜야 한다(문자, 언더바, 달러기호 만 가능 시작할때) */
// 변수: 값이 변하는거 (내가 지정하거나)
/* 암시적 선언 - 변수를 정의하는 키워드를 적지 않음 
EX) sum = 10; 추천하진 않음
명시적 선언 - let sum = 10; let을 적고 선언 
##변수 선언시 클래스,아이디값 처럼 누가봐도 의미를 알수있게
여러 변수를 연결하는 낙타표기법 - 대소문자로 뽀록하게
????
카멜표기법, 스네이크 표기법
*/

/* ###자바스크립트 실습 버튼### */
// function 어떤 기능을 구현할수있는게 함수
// function clac() {
//   const currentYear = 2023;
//   let birthYear = prompt("태어난 년도를 입력하세요!","");
//   let age;
//   age = currentYear = birthYear + 1;
//   document.querySelector("#result").innerHtml = "당신의 나이는 " + age + "세 입니다!";
// }


/* 자바스크립트 > 변수를 선언하는 키워드 3개
'var' 라는 변수는 잘 안쓴다. 초창기에 나온 변수
장점:유연하다(변수를 만들때 동일한 이름으로 변수선언이 가능하다
 = 동일한 변수명에 여러 값을 넣어도 작동한다. 그래서 협업시 심하게 꼬일수가 있다. 개발자간 변수 충돌 가능성 높음 ) */
// var num = 10;
// document.write(num, "<br />");
// var num = 20;
// document.write(num);

// const = let보다 더 엄격, 변수보다는 상수를 선언할때, 고정값
// let은 변수값 수정 가능, const는 변수값 수정 불가
// let box;
// box = 100;
// box = 30; 
// document.write(box, "<br />");

// let box1 = 30;
// document.write(box1);

// let num1 = 100; 
// let num2 = '100';
// let result = num1 + num2

// document.write(num1, "<br />");
// document.write(num2, "<br />");
// document.write(result)
/*문자열인지 숫자열인지 확인하는 법 콘솔창 - typeof 변수명
-숫자인지 문자인지 알려줌 */
// const a = true;
// const b = false;
// const c = 10 > 5;
// const d = Boolean(null); //boolean 논려형, null은 빈공간 값이 안들어가있다. 빈공간은 false

// document.write(a, "<br />");
// document.write(b, "<br />");
// document.write(c, "<br />");
// document.write(d, "<br />");

// let a = 100;
// let b = '200';
// let c = a + Number(b); // 문자열에 Number()을 주면 숫자로 받아들인다

// document.write(c);



// 변수의 값을 리셋시킬때 null
// undefined = 값이 없다. 뭘 출력해야 될지 모르겠다
// 자료형이다
// let s;
// document.write(s, "<br />");

// let t = "hello";
// t = null; 
// document.write(t);

// ### 변수명을 일일이 작성해야 되는경우
// let spring = "봄";
// let summer = "여름";
// let fall = "가을";
// let winter = "겨울";

// 변수를 한번에 지정 가능 [] 대괄호
// let seasons = ["봄", "여름", "가을", "겨울"];
// seasons[2];
/*배열객체 
배열의 내용은 index, index는 0부터, 아이템의 갯수는 length(fodtm) 
불러올때는 seasons[1]; 아이템 넘버*/