// let count = 0;

// function myFnc() {
//   count++;
//   document.write("hello" + count, "<br />");
// }
// myFnc(); //함수호출
// myFnc(); //함수호출
// myFnc(); //함수호출



// let theFnc = function() {
//   count++
//   document.write("bye" + count, "<br />")
// }

// theFnc()



// let color = ["white", "yellow", "aqua", "purple"];

// let i = 0;
// function changeColor() {
//   i++;
//   if(i >= color.length) {
//     i = 0;
//   }
//   let bodyTag = document.getElementById("theBody");
//   bodyTag.style.backgroundColor = color[i];
// }

// function addNum() {
//   let sum = 10 + 20;
//   document.write(sum);
// }
// addNum();

// let num1 = parseInt(prompt("첫번째 숫자는?", "0"));
// let num2 = parseInt(prompt("두번째 숫자는?", "0"));
// addNum(num1, num2)

// function addNum(a, b) {
//   let sum = a + b;
//   document.write(sum, "<br />");
// }

// let myVar = 100;
// test();
// document.write("myVar is"+ myVar);

// function test() {
//     myVar = 50;
// }


// let color = ["white", "yellow", "aqua", "purple"];

// let i = 0;
// function changeColor() {
//   i++;
//   if(i >= color.length) {
//     i = 0;
//   }
//   let bodyTag = document.getElementById("theBody");
//   bodyTag.style.backgroundColor = color[i];
// }

function changeColor() {
  let arrColor = ["#ff0", "#6c0", "#fcf", "#cf0", "#39f"];
  let arrNum = Math.floor(Math.random() * arrColor.length);
  let bodyTag = document.getElementById("theBody")
  bodyTag.style.backgroundColor = arrColor[arrNum];
}