let pic = document.querySelector('#pic');
pic.addEventListener("mouseover", changePic);
pic.addEventListener("mouseout", originpic);


function originpic() {
  pic.src = "/imges/girl.png";
}

function changePic() {
  pic.src = "/imges/boy.png"
}