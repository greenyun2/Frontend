const openButton = document.querySelector('.open');
const container = document.querySelector('.container');
const closeButton = document.querySelector('.close');
const imgBtn = document.querySelector('.imgBtn');

const showMe = document.querySelector('.show');
const avenGers = document.querySelector('avengers')

openButton.addEventListener('click', () => {
  container.style.display = 'flex';
  openButton.style.display = 'none';
});

closeButton.addEventListener('click', () => {
  container.style.display = 'none';
  openButton.style.display = 'block';
});

imgBtn.addEventListener('click', () => {
  openButton.style.display = 'block';
  container.style.display = 'none';
});

showMe.addEventListener('click', () => {
  container.style.display = 'none'
  avenGers.style.display = 'block'
  openButton.style.display = 'none'
});
