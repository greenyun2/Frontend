let check = document.querySelector('#shippingInfo');

check.addEventListener('click', function() {
  if(check.checked == true) {
    document.querySelector('#shippingName').value =
    document.querySelector('#billingName').value;

    document.querySelector('#shippingTell').value = 
    document.querySelector('#billingTell').value;

    document.querySelector('#shippingAddr').value = 
    document.querySelector('#billingAddr').value;
  } else {
    document.querySelector('#shippingName').value = "";
    document.querySelector('#shippingTelll').value = "";
    document.querySelector('#shippingAddr').value = "";
  }
});