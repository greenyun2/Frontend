$(document).ready(function(){
  $(".slider").bxSlider({
    mode: "horizontal",
    speed: "500",
    auto: true,
    pause: "3000",
    moveSlides: 2,
    autoHover: true,
    autoControls: true,
    pager: false
  });
});