$(function(){
  $('#title').css("color", "red");
});
