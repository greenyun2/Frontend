<?php
  $data = '[
    {"id":"1","name":"Sofet","email":"sejin@tcos.com"}
    {"id":"2","name":"levi","email":"welf@tcos.com"}
    {"id":"3","name":"Excel","email":"asadk@tcos.com"}
  ]';
  echo $_GET["callback"]."(".$data")";
?>