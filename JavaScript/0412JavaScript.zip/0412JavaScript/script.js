// function random(number) {
//   return Math.floor(Math.random() * number);
//   }

//   function bgChange() {
//     const rndCol = 'rgb(' + random(255) +','+ random(255) +','+ random(255) +')';
//     document.body.style.backgroundColor = rndCol
//   }

//   bgChange();
// let fruit = ["딸기", "수박", "메론", "바나나"]
// console.log(fruit[1])
// Symbol() : 객체의 자료중 유일한 혹은 유니크한 키 값을 부여하고 싶을때 사용함
// 테스트 - 내가 작성
// let fah = prompt("화씨온도를 알려주세요")
// let degree = parseFloat((fah - 32) / 1.8)
// let result = `화씨 ${fah}도는 섭씨 ${degree}도 입니다.`

// document.write(result)
//테스트 - 답안
// let fah = parseInt(prompt("화씨온도를 알려주세요"));
// let cel = ((fah - 32) / 1.8).toFixed(1);

// alert(`화씨 ${fah}도는 섭씨 ${cel}도 입니다`);

// if (num1 < num2) {
//   small = num1;
// } else {
//   small = num2;
// }

// 삼항조건연산자 
// 조건 ? true일때 실행할 명령문 : false일때 실행할 명령문

// small = (num1 < num2) ? num1 : num2; //3항 3개의 항 1이 2보다 작을때 스몰에 1번값을 아니라면 2번에 변수 스몰에 2를 넣어줘
// 내가 작성한거
// let userNum = parseInt(prompt("숫자를 입력해 주세요"));

// if (userNum % 2 == 0) {
//   alert("짝수입니다");
// } else {
//   alert("홀수입니다");
// } 
// 테스트 답안
// let userNum = parseInt(prompt("숫자를 입력해 주세요"));

// if (userNum !== null) {
//   (userNum % 2 ==0 ) ? alert(`${userNum} : 짝수입니다`) : alert(`${userNum} : 홀수입니다`)
// };
// switch(조건) {
//   case 값 : 문장
//     break 
//   case 값 : 문장
//     break
//   case 값 : 문장
//     break
//   case 값 : 문장
//     break
//   default : 문장
// }
// Swich문
// let subject = prompt("신청할 과목을 선택하세요 1-HTML, 2-CSS, 3-JavaScript");

// if (subject !== null) {
//   switch(subject) {
//     case "1" : document.write("HTML을 신청했습니다.")
//     break;
//     case "2" : document.write("CSS을 신청했습니다.")
//     break;
//     case "3" : document.write("JavaScript을 신청했습니다.")
//     break;
//     default : document.write("잘못 입력했습니다. 다시 입력해주세요!")
//   }
// } 
// if 논리 연산자를 활용
// const num1 = parseInt(prompt("첫 번째 정수 : "));
// const num2 = parseInt(prompt("두 번째 정수 : "));
// let str;

// if (num1 % 2 === 0 && num2 % 2 ===0) {
//   str = "두 수 모두 짝수입니다!"
// } else {
//   str = "짝수가 아닌 수가 있습니다!"
// }
// alert(str);
// for문을 활용
// for (초기갑; 조건식; 증감문) {
//   반복할 실행문
// }
// const students = ["park","kim","lee","kang"];

// for (let i = 0; i < students.length; i++) {
//   document.write(`${students[i]}, `);
// }

// let color = ["white","black","blue","red"];
// for (let i = 0; i < color.length; i++) {
//   document.write(`${color[i]}. `)
// }
// 지금까지 배운 for문 기본형!!
// ~ forEach() 함수 : 배열객체에서 각각의 요소들을 꺼내서 반복시키고자 할때!
// ~ forEach(콜백함수) 함수의 매개변수에 인자값으로 들어갔다
// > 콜백함수란 : 다른 함수의 인자값으로 사용되는 함수를 의미합니다!
// > 인자값 = 인수 : 매개변수의 값으로 적용될 값 
// > 매개변수 = function("여기에 들어가는 매개변수") : 함수가 작동하기 위해서 존재해야하는 값 

// const students = ["park", "lee", "kim", "hwang"];

// students.forEach(function(stundent) {
//   document.write(`${stundent}. `)
// });
//콜백함수 안에 들어가는 변수명은 임시변수, 참조한다 해서 참조변수 이름은 뭘쓰던 상관없다 
// foreach():
// let fruits = ["수박", "딸기", "귤", "청포도", "맛좋은바나나"]

// fruits.forEach(function(fruit) {
//   document.write(`${fruit}. `)
// })
// forEach(): 배열개체에서 각각의 요소를 반복시킬 때
// for in문: 일반객체에서 각각의 객체안에 있는 프로퍼티(*키 : value)을 가져와서 반복시킬 때

const bookInfo = {
  title : "자바스크립트",
  pubData : "2023-04-11",
  pages : 272,
  finished : true
}
for(let i in bookInfo) {
  document.write(`${i} : ${bookInfo[i]}<br />`)
}
//key 자리에 아무거나 넣어도 상관없다. i로 많이 쓰기도 한다(인덱스값이니까)