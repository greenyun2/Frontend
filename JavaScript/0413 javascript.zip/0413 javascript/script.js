// if
// else if

// for
// foreach():배역객체 > 아이템 요소 반복
// for in : 변수 in 객체
// for of : 문자열 혹은 백열객체에서 반복가능한 반복문
// for 3가지 종류
// for in = 일반객체에서 객체의 값을 가져와서 반복처리

// for of = : 배열객체에서 각각의 변수값을 가져와서 반복처리할 때 주로 사용 = forEach
// 배열객체 안에 들어가는걸 반복해서 처리
// .forEach()
// while : 조건이 참인 경우 문장을 반복
// while (조건) {
//   실행할 명령
// }

// do while : 참.거짓 여부와 상관없이 무조건 1회 반복 후 조건식을 참고
// do {
//   실행할 명령(출력)
// } while (조건)
// let stars = parseInt(prompt("별의 개수 : "));

// while (stars > 0) {
//   document.write("*");
//   stars--;
// }

//실행할 명령문이 먼저 실행되기 때문에 참이든 거짓이든 일단 한번 실행한다
// do {
//   document.write("*")
//   stars--;
// } while(stars > 0)
// 반복문

// > break문 : 반복문을 강제종료!

// > continue문 : 특정조건에 해당되는 값을 만났을때, 실행하던 반복 문장을 건너뛴다!

// 실습 : 소수 인지 아닌지 알려주는거
// const number = parseInt(prompt("숫자를 입력하세요!"));
// let isPrime;
// // 숫자 1은 소수도 합성수도 아니다
// // 숫자 2는 소수입니다
// if (number === 1) {
//   document.write(`${number}은 소수도, 합성수도 아닙니다.`);
// } else if (number === 2) {
//   isPrime = true;
// } else {
//   for (let i = 2; i < number; i++) {
//     if (number % i === 0) {
//       isPrime = false;
//       break
//     } else {
//       isPrime = true
//     }
//   }
// }

// if (isPrime) {
//   document.write(`${number}는 소수야!`)
// } else {
//   document.write(`${number}는 소수가 아니야!`)
// }

// 내가 쓴거
// let number = ["1","3","5","7","9","11","13","15","17","19"];
// for(let el of number) {
//   if (el > 10) {
//     document.write(`${el}. `)
//   }
// }

// 답안
// const arr = [1, 3, 5, 7, 9, 11, 13, 15, 17, 19]
// for(let i = 0; i < arr.length; i++) {
//   if (arr[i] > 10) {
//     document.write(`${arr[i]}, `);
//   }
// }

// 입력한 숫자에서 짝수
// let userNum = parseInt(prompt("1보다 큰 숫자를 입력해주세요"));
// if (userNum !== null || userNum <= 1) {
//   alert("1보다 큰 숫자를 입력해주세요");
// } 
// let arr
// for (i = 0; i < userNum; i++) {
//     arr = (userNum % 2 == 0)
//     if (arr ) {

//     }
// }

// 답안지
// let n = parseInt(prompt("1보다 큰 숫자를 입력하세요"));
// let sum = 0

// if (n !== null && n > 1) {
//   for (let i = 1; i <= n; i++) {
//     if (i % 2 == 1) {
//       continue;
//     }
//     sum += i;
//     document.write(`${i} ------ ${sum} <br />`)
//   }


// function calcSum() {
//   let sum = 0;
//   for(let i = 1; i <= 10; i++) {
//     sum += i;
//   }
//   console.log(`1부터 10까지 더하면${sum} 입니다.`)
// }
// calcSum()
// 사용자로 하여금 특정값을 받아서 함수를 실행시키고자 할때 매개변수가 필요하다

// 매개변수에 전달될 값 = 인수 혹은 인자값

// function sum(매개변수) {

// }

// let a = parseInt(prompt("값을 입력하세요"))
// let b = parseInt(prompt("값을 입력하세요"))

// function sum(a, b) {
//   let result = a + b;
//   alert(`두 수의 합: ${result}`)
// }
// sum()

// function calcSum(n) {
//   let sum = 0;
//   for(let i = 1; i <= n; i++) {
//     sum += i
//   }
//   console.log(`1부터 ${n}까지 더하면 ${sum} 입니다`)
// }
// calcSum(10)

// function calcSum(n) {
//   let sum = 0;
//   for(let i = 1; i <= n; i++) {
//     sum += i;
//   }
//   return sum;
// }
// let num = parseInt(prompt("몇까지 더할까요?"));
// document.write(`1부터 ${num}까지 더하면 ${calcSum(num)}`);

// 내가 작성
// let a = parseInt(prompt("숫자를 입력해주세요!"));
// let b = parseInt(prompt("숫자를 입력해주세요!"));
// function userNum(a, b) {
//   if (a !== null && b !== null){
//     let result = a * b;
//     return result
//   }
// }
// document.write(userNum(a, b))

// 답안
// let a = parseInt(prompt("숫자를 입력해주세요!"));
// let b = parseInt(prompt("숫자를 입력해주세요!"));
// function userNum(a, b) {
//     return a * b
//   }
// document.write(userNum(a, b))

//매개변수 기본값 지정하는 방법
// function multiple(a, b =5, c=10) {
//   return a * b + c
// }
// console.log(multiple(5, 10, 20))
// console.log(multiple(10, 20))
// console.log(multiple(10))

// function calcSum(n) {
//   let sum = 0;
//   for (let i =1; i <= n; i++) {
//     sum += i;
//   }
//   console.log(`1부터 ${n}까지 더하면 ${sum}입니다/`)
// }
// calcSum(10);
// 함수 스코프 = 적용범위
// > 어떠한 함수가 영향을 미칠 수 있는 적용범위
// 1) 지역스코프 = local
// > 지역 변수

// 2) 전역스코프 = Global
// > 전역 변수

// const factor = 5;
// function calc(num) {
//   return num * factor
// }

// {
//   // 뒤에서라도 함수에 인자값을 넣어줘야 한다
//   let result = calc(10);
//   document.write(`result : ${result}`)
// }
// 스코프 = 영역 범위 
// 지역스코프
// 전역스코프
// 블록스코프

/*var, let, const의 차이점*/
// function addSum(n) {
//   var sum = 0;
//   for (var i = 1; i <= n; i++) {
//     sum += i;
//   }
//   return sum;
// }
// var num = 3;
// console.log(`1부터 ${num}까지 더하면 : ${addSum(num)}`)

// function addSum(n) {
//   let sum = 0;
//   for (let i = 1; i <= n; i++) {
//     sum += i;
//   }
//   return sum;
// }
// const num = 3;
// console.log(`1부터 ${num}까지 더하면 : ${addSum(num)}`)

/**익명함수: 함수이름을 정의하지 않은 함수 
let sum = function(a, b) {
}
const sum() = function(a, b) {
}
함수의 이름을 변수가 대신한다 
이때 변수는 참조변수라 부르고
함수를 익명함수라 한다
*/
// 자바스크립트 함수 => 1급 함수!!!
// 함수를 익명으로 선언!
// 함수를 변수값으로 할당!
// 즉시 실행 함수!!!
// : 함수를 정의하면서 동시에 실행시키는 함수

// 즉시 실행 함수 형태
// (function(매개변수) {

// }(인자값)) 
// ##화살표 함수
// 1.매개변수가 없을 때
// ex) let hi = () => { return `엔뇽하세요`};
// ex-축약버전) let hi = () => 엔뇽하세요`;
// 1.
// let hi = function() {
//   return `엔뇽하세요`
// }
// 2. 화살표함수
// let hi = () => { return `엔뇽하세요`};
// 3. 화살표함수 축약버전
// let hi = () => `엔뇽하세요`;

// ####매개변수가 있을때의 화살표 함수
// let sum = function(a,b) {
//   return a + b;
// }
// sum(10, 20)

// let sum = (a, b) => a + b 
// sum(10, 20)

// 콜백함수
// 콜백함수 > 함수안에 인수가 되는 또다른 함수
// const btn =document.querySelector("button");

// btn.addEventListener('click', () => {
//   alert("클릭했습니다.")
// });

// let num1 = parseInt(prompt("숫자를 입력해주세요"))
// let num2 = parseInt(prompt("숫자를 입력해주세요"))

// let mult = (a, b) => a * b

// document.write(`${mult(num1, num2)}`)

// function showData(name, age) {
//   alert(`안녕하세요! ${name}님. 나이가 ${age}살 이군요!`)
// }

// function getData(callback) {
//   let userName = prompt("이름을 입력하세요!");
//   let userAge = parseInt(prompt("나이를 입력하세요!"));
//   callback(userName, userAge);
// }
// getData(showData);
// setInterval()
// > 사용법 : setInterval(콜백함수. 시간)
// > 일정한 시간마다 함수를 반복해서 실행하는 함수
// > 자바스크립트는 밀리초를 사용한다. 1000밀리초 = 1초
// function greeting() {
//   console.log("안녕하세요!");
// }

// setInterval(() => {console.log("안녕!")}, 2000);

// function hello() {
//   for(let i = 0; i < 5; i++){
//     setInterval(() => {console.log("안녕하세요!")}, 2000)
//   } return 
// } 
// document.write(hello())

// let counter = 0;

// let timer = setInterval(() => {
//   console.log("안녕하세요!")
//   counter++;
//   if (counter === 5){
//     clearInterval(timer);
//   }
// },2000);
// setTimeout() : 일정시간 이후에 콜백함수를 실행!!

// setTimeout(() => {
//   console.log("안녕세요")
// }, 3000);

// let userNum = parseInt(prompt("숫자 입력해라")); 

// let nembers = () => {
//   if(userNum == 0) {
//     alert("0입니다")
//   } return document.write(Math.sign(userNum))
// }
//답안
//isNaN(매개변수) : 매개변수가 숫자인지 아닌지를 검사하는 함수!!
const number = parseInt(prompt("숫자를 입력하세요!"));

if(!isNaN(number)) {
  isPasitive(number);
}
function isPasitive(number) {
  if (number > 0) {
    alert(`${number}는 양수입니다!`);
  }else if (number < 0) {
    alert(`${number}는 음수입니다`)
  } else {
    alert(`0입니다`)
  }
}