const first = document.querySelector("#first");
const second = document.querySelector("#second");
const calculate = document.querySelector("button");
const result = document.querySelector("#result");


function getGCD(n, m) {
    let max = n > m ? n : m
    let gcd = 0;
    for (let i = 1; i <= max; i++) {
      if(n % i === 0 && m % i === 0) {
        gcd = i;
      }
    }
    return gcd;
}

calculate.onclick = () => {
  result.innerText = getGCD(first.value, second.value)
}
