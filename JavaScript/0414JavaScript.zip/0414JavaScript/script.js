// 최대공약수 구하기 만들기
// const num1 = parseInt(prompt("첫번째 숫자 입력해주세요"))
// const num2 = parseInt(prompt("두번째 숫자 입력해주세요"))

// function getGCD(n, m) {
//   let max = n > m ? n : m
//   let gcd = 0;
//   for (let i = 1; i <= max; i++) {
//     if(n % i === 0 && m % i === 0) {
//       gcd = i;
//     }
//   }
//   return gcd;
// }

// document.write(`${num1}와 ${num2}의 최대공약수는 : ${getGCD(num1, num2)}`)

// DOM document Object Model = 태그를 가져올려면 문서객체모델을 알아야 노드를 알수있다
// 문서객체모델 > 최상위클래스 : document 객체 
// body 객체 ="요소","객체" 동일한 의미
// h1 객체 = "요소","객체" 동일한 의미
// p  객체 ="요소","객체" 동일한 의미
// input 객체
// 객체 : 속성(*프로퍼티 = property) / 기능(*매서드 = method)

// html > 문서구조 > 태그 = 객체 > 요소
// : 요소에 접근한다!
// 요소에 접근할수 있는 함수!!
// 1.queySelector(h1)
// > 무조건 낱개 요소에 접근!!
// > 매개변수에 입력한 선택자에 접근
// > 해당 선택자가 document 안에 다수 존재하는 경우, 가장 첫번째로 선택된 요소에 접근한다

// 단일 요소에 접근 : querySelctop()
// 모든 요소에 접근 : querySelctopAll()

// ex  querySelctor(".user") 클래스 값중 첫번째
//     querySelctopAll(".user") 모든 클래스값

//     getElementById() 
//     getElementsById() 
//     getElementByTagName() 
//     Element = 태그까지만
//     querySelctor = 태그 안에있는 요소까지

// 요소데이터 가져오는 방법
// 웹 요소 .innerText(웹브라우저에 출력되고 있는 내용을 보여준다)
// 웹 요소 .innerHTML(HTML의 소스코드를 다 가져옴)
// 웹 요소 .textContent(태그를 제외한 텍스트요소만 보고싶다면)

// 바꾸고 싶은 내용
// 웹 요소 .innerText = 바꾸고 싶은 내용
// 웹 요소 .innerHTML = 바꾸고 싶은 내용
// 웹 요소 .textContent = 바꾸고 싶은 내용

// 웹요소.src = 바꾸고 싶은 이미지 파일

// const userName = document.querySelector("#desc p");
// const pfImg = document.querySelector("#profile img");

// userName.onclick = () => userName.innerHTML = `이름 : <b>그냥노창</b>`;
// pfImg.onclick = () => pfImg.src = "/img/노창.jpg";

// CSS속성에 접근하고 스타일 수정하는 방법!!
// 수정하고 싶은 요소.style.속성명 = 바꾸고 싶은 스타일값

// const title = document.querySelector("#title");
// const name = document.querySelector(".user")

// title.onclick = () => {
//   title.sytle.backgroundColor = "black";
//   title.style.color = "white";
// }

// name.onclick = () => {
//   name.style.color = "blue"
// }
// classList 속성 (*프로퍼티) :
// - 해당 요소의 클래스값을 배열객체 형태로 찾아줍니다!!!
// 선택한 선택요소.classList.add("클래스명")
// > 선택한 선택요소에 클래스명을 추가할 때 사용

// 선택한 선택요소.classList.remove("클래스명")
// > 선택한 선택요소에 클래스명을 삭제할 때 사용

// 선택한 선택요소.classList.contains("클래스명")
// > 선택한 선택요소에 클래스명이 있는지 여부를 확인하는 함수
// 
// 선택한 선택요소.classList.toggle("클래스명")
// > 선택한 선택요소에 클래스명이 있는지 여부를 확인하여 추가 및 삭제를 반복하는 함수
// const title = document.querySelector("#title");

// title.onclick = () => {
//   if(!title.classList.contains("clicked")) {
//     title.classList.add("clicked");
//   } else {
//     title.classList.remove("clicked");
//   }
// }

// const night =document.querySelector("body");

// night.onclick = () => {
//   night.classList.toggle("clicked")
// }

// const btn = document.querySelector("button");

// btn.onclick = function() {
//   document.body.classList.toggle("dark");
//   if(btn.innerHTML == "다크모드로 바꾸기") {
//     btn.innerHTML = "라이트모드"
//   } else if (btn.innerHTML

//   )
// }