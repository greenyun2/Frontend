const viewBtn = document.querySelector("#view");
const detail = document.querySelector("#detail")

viewBtn.onclick = () => {
  detail.classList.toggle("hidden");
}

