// // ### Test ###
// // dark/light button
// const btn = document.querySelector("button");
// const body = document.querySelector("body");

// btn.onclick = () => {
//   document.body.classList.toggle("dark");
//   if(btn.innerHTML == "다크모드로 바꾸기") {
//     btn.innerHTML = "라이트모드로 바꾸기";
//   } else if(btn.innerHTML == "라이트모드로 바꾸기") {
//     btn.innerHTML = "다크모드로 바꾸기";
//   }
// };
// // form 태그 안에서 button 기본 type = submit
// // => html > button type="button" 으로 type 초기화

// //select alert
// const userName = document.querySelector("#userName");
// const selectMenu = document.querySelector("#programs");

// function displaySelect() {
//   let selectedText = selectMenu.options[selectMenu.selectedIndex].innerText;
//   alert(`${userName.value}님, ${selectedText}를 선택했습니다!`);
// }
// selectMenu.onchange = displaySelect;

// ##########################################

// 이벤트 : 웹 브라우저 안에서 사용자가 실행하는 모든 동작
// 1) 문서 로딩 이벤트 (ex. abort, error, load, ...)
// 2) 마우스 이벤트 (ex. click, )
// 3) 키보드 이벤트 (ex. keydown, )
// 4) 폼 이벤트

// window.onload = alert("안녕하세요");
// load: 특정 문서의 로딩이 끝났을 때, 어떠한 결과를 보여주는 이벤트
// on키워드 + 이벤트: 이벤트 핸들러
// 이벤트 핸들러: 이벤트가 발생하면, 이벤트에 맞는 연결동작이 필요! 이벤트 연결동작을 처리하는 것

// 1. 키보드에 어떤 키를 클릭했을 때, 해당 키를 출력할 공간 정의
// 2. 어떤 키를 눌렀는지에 대한 정의값 필요
// *키보드 이벤트 > 문서객체 > body 태그

// // ### keydown ###
// const body = document.body;
// const result = document.querySelector("#result");

// body.addEventListener("keydown", (e) => {
//   result.innerText = `code: ${e.code}, key: ${e.key}`;
// })

// ##########################################

// 자바스크립트에서 이벤트가 작동될 수 있는 2가지 방법
// 1. HTML 태그에 직접 함수를 연결하는 방법
// > <태그 이벤트핸들러 = "함수명">
// 문제점: 복수의 이벤트를 적용하고 싶은 경우

// 2. 자바스크립트에서 직접 함수를 연결하는 방법
// > 선택요소 (*이벤트를 주고싶은 요소).이벤트핸들러 = 함수

// case 1
// const button = document.querySelector("button");

// button.onclick = () => {
//   document.body.style.backgroundColor = "green"
// }

// case 2
// const button = document.querySelector("button");

// function changeBG() {
//   document.body.style.backgroundColor = "green"
// }
// button.onclick = changeBG;

// practice
// const button = document.querySelector("button");

// button.onclick = () => {
//   alert("안뇽");
//   document.body.style.backgroundColor = "#222";
//   document.body.style.color = "#fff";
// }

// addEventListener(복수의 이벤트 적용 가능)
// 사용방법
// 선택요소.addEventListener(이벤트명,함수)

// const button = document.querySelector("button");

// function changeBG() {
//   document.body.style.backgroundColor = "green"
// }
// button.addEventListener("click", changeBG);
// // html 태그에 이벤트를 줌과 동시에 복수 적용 가능

// practice
// const button = document.querySelector("button");
// button.addEventListener("click", function() {
//   document.body.classList.toggle("convert")
// })


// // ### 텍스트 글자수확인 ###
// const button = document.querySelector("button");
// button.addEventListener("click", () => {
//   const word = document.querySelector("#word");
//   let count = word.value.length;
//   const result = document.querySelector("#result");

//   result.innerText = `${count}`;
// });

// ##########################################

// ### 나이트모드 & 프로필 여닫기 ###
// const daynightBtn = document.querySelector("#daynight");
// daynightBtn.onclick = () => {
//     document.body.classList.toggle("dark");
//     if(daynightBtn.innerHTML == "다크모드로 바꾸기") {
//       daynightBtn.innerHTML = "라이트모드로 바꾸기";
//     } else if(daynightBtn.innerHTML == "라이트모드로 바꾸기") {
//       daynightBtn.innerHTML = "다크모드로 바꾸기";
//     }
//   };

// const open = document.querySelector("#open");
// const modalBox = document.querySelector("#modal-box");

// open.onclick = () => {
//   modalBox.classList.toggle("active");
//   if(open.innerHTML == "프로필 보기") {
//     open.innerHTML = "프로필 닫기";
//   } else if(open.innerHTML == "프로필 닫기") {
//     open.innerHTML = "프로필 보기";
//   }
// };

// ##########################################

// 이벤트 객체 : 어떤 요소에서 어떤 이벤트가 발생했는지에 대한 정보가 포함된 객체
// 이벤트 객체 메서드 예시
// preventDefault()
// 이벤트 객체 프로퍼티 예시
// pageX & pageY
// target

// const box = document.querySelector("#box");
// box.addEventListener("click", function(e) {
//   alert(`이벤트 발생 위치: ${e.pageX}, ${e.pageY}`)
// })

// // ### 키보드 이벤트 ###
// // e.code & e.key
// const body = document.body;
// const result = document.querySelector("#result");

// body.addEventListener("keydown", (e) => {
//   result.innerText = `
//   code : ${e.code},
//   key : ${e.key}
//   `
// })


// ### 슬릭 슬라이더 만들기 ###
// //오른쪽버튼 사용금지하기
// window.addEventListener("contextmenu", (e) => {
//   e.preventDefault();
//   alert(`오른쪽 버튼을 사용할 수 없습니다!`)
// });

// const container = document.querySelector("#container");
// const pics = ["pic-1.jpg", "pic-2.jpg", "pic-3.jpg", "pic-4.jpg", "pic-5.jpg", "pic-6.jpg"];

// container.style.backgroundImage = `url(/img/${pics[0]})`;
// const arrows = document.querySelectorAll(".arrow");
// let i = 0;

// arrows.forEach((e) => {
//   e.addEventListener("click", (e) => {
//     if(e.target.id === "left") {
//       i--;
//       if(i < 0) {
//         i = pics.length - 1;
//       }
//     } else if (e.target.id === "right") {
//       i++;
//       if(i >= pics.length - 1) {
//         i = 0;
//       }
//     }
//     container.style.backgroundImage = `url(/img/${pics[i]})`;
//   });
// });

// ##########################################

// 이벤트전파
// 1) 이벤트 버블링
// : 이벤트가 부모요소 & 부모의 부모 요소에도 적용
// 2) 이벤트 캡쳐링
// : 
// const elements = document.querySelectorAll("*");

// // for (let 변수 of 객체)
// for (let el of elements) {
//   el.addEventListener("click", e => {
//     console.log(`e.target : ${e.target.tagName}, e.currentTarget : ${e.currentTarget.tagName}`), false
//   })
// }

// // ### 마우스오버 사진바꾸기 ###
// const container = document.querySelector("#container");
// container.style.backgroundImage = `url(/img/pic-1.jpg)`;
// container.addEventListener("mouseover", () => {
//     container.style.backgroundImage = `url(/img/pic-6.jpg)`;
// })
// container.addEventListener("mouseout", () => {
//     container.style.backgroundImage = `url(/img/pic-1.jpg)`;
// })

// ### 메뉴 네비게이션 ###
// const btn = document.querySelector("#btn");
// const nav = document.querySelector("#nav");

// btn.addEventListener("click", () => {
//   nav.classList.toggle("active");
//   btn.classList.toggle("active");
// });

// ##########################################

// <<지금까지 배운 것들!!>>
// 다크모드
// 모달/ 좌측네비게이션 / 슬라이더
// 오른쪽 버튼 사용금지
// 마우스오버/아웃 이벤트
// 마우스이벤트: 좌표값 확인