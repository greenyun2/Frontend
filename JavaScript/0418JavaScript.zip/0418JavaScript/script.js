// 모든 HTML 태그는 요소 노드가 됩니다.
// HTML 태그에서 사용하는 텍스트 내용은 자식노드

// HTMl태그에서 속성은 모두 자식노드

// *노드리스트!!!
// querySelectot() : 단일 요소를 선택
// querySelectotAll() : 복수 요소를 선택

// *기존에 없던 새로운 노드를 만들어서 추가하고 싶은경우!!
// document.createElement(생성하고싶은 요소명)
// 노드 요소를 추가한 경우 
// let newP = document.createElement("p");
// let textNode = document.createTextNode("Typescript");
// newP.appendChild(textNode);
// document.body.appendChild(newP);
// document.createElement(생성하고싶은 요소 = 태그)
// document.createTextNode(생성하고 싶은 텍스트)
// 부모요소.appendChild(자식노드) = 부모요소에 자식으로 들어간다~

// 내가 쓴 답안
// const btn = document.querySelector("#order");
// let newP = document.createElement("h2");
// let textNode = document.createTextNode("2023신상 에어맥스 풀파워!!");
// let orderName = document.querySelector("#orderInfo")

// btn.addEventListener("click", () => {
//   newP.appendChild(textNode);
//   orderName.appendChild(newP);
// });

// 강사님 답안
// 1. 주문하기 라는 버튼 정의
// 2. 아래 내용이 나와야하는 출력공간 정의
// 3. 출력공간에 보여줄 컨텐츠 정의
// const orderBtn = document.querySelector("#order");
// const orderInfo = document.querySelector("#orderInfo");
// const title = document.querySelector("h2");

// orderBtn.addEventListener("click", () => {
//   let newP = document.createElement("p");
//   let textNode = document.createTextNode(title.innerText);

//   newP.appendChild(textNode);
//   newP.style.fontSize = "0.8em";
//   newP.style.color = "blue";
//   orderInfo.appendChild(newP);
// }, {once : true}); // 한번만 하고 끝!


// createElement() : 요소(*태그) 노드 만들기
// createTextNode() : 텍스트 노드 만들기
// appendChild() : 부모요소에 자식요소 만들기
// createAttribute() : 속성 노드 만들기
// setAttributeNode(): 속성 노드 연결하기

// 1. 변수에 이미지 태그 만들기
// 2. 변수에 이미지 src 속성만들기
// 3. 이미지 속성을 정의해준 변수에 변수.value = "/img/아이유.jpg"
// 4. 이미지 태그.setAttributeNode("속성을 정의해준 변수")
// 5. document.body.appendChild(이미지태그)

// 오전/오후 시간에 따라 바뀌는 이미지 만들기
// 1. 시간(*오전 / 오후)에 대한 개념 정의
// 2. 시간 변화에 따라서 출력해줘야하는 이미지가 어떤것인지에 대한 정의
// > 시간 변화 정의 - 이미지 정의
// 3. 이미지를 출력할 공간에 대한 정의

// const container = document.querySelector("#container");
// const today = new Date();
// const hrs = today.getHours();

// let newImg = document.createElement("img");
// newImg.src = (hrs < 12) ? "/img/morning.jpg" : "/img/afternoon.jpg";
// container.appendChild(newImg);

// 노드를 만들어서 자녀요소로 추가!!! 
// > 가장 마지막 영역에 추가!!! 
// > appendChild(자녀요소) : 부모요소에 가장 마지막 위치로 자녀를 편입시킴!! 

// *기존 노드의 앞에 새 요소로 추가하고자 할 때 사용하는 메서드 함수
// : insertBefore(앞의 추가하고자 하는 요소, 기준점이 되는 요소)

// let tsNode = document.createElement("p");
// let tsTextNode = document.createTextNode("TypeScript");

// tsNode.appendChild(tsTextNode);
// let basisNode = document.querySelectorAll("p")[0];
// document.body.insertBefore(tsNode, basisNode);

// 내가 작성한 답안
// const addTextBtn = document.querySelector("button");

// let newP = document.createElement("p");
// let pTextNode = document.createTextNode("TypeScript");
// newP.appendChild(pTextNode);

// let pTag = document.querySelectorAll("p")[2]


// addTextBtn.addEventListener("click", () => {
//   document.body.insertBefore(newP, pTag);
// });

//강사님 답안
// 1. 텍스트추가 라는 버튼에 정의
// 2. 추가하고자 하는 컨텐츠에 대한 정의
// 3. 해당 컨텐츠가 출력되어야 하는 공간에 대한 정의

// const button = document.querySelector("button");

// button.addEventListener("click", () => {
//   let tsNode = document.createElement("p");
//   let tsTextNode = document.createTextNode("TypeScript");
//   tsNode.appendChild(tsTextNode);
//   const basisNode = document.querySelectorAll("p")[2];
//   document.body.insertBefore(tsNode, basisNode)
// });

// 노드 추가하거나 생성하거나 편입시키는 메서드
// - 노드 삭제하는 메서드
// > remove() :
// > 삭제하고자 하는 요소.remove()

// let heading = document.querySelector("h1");
// heading.remove();

// const title = document.querySelector("h1");

// title.addEventListener("click", () => {
//   title.remove()
// });

// remove() : 선택된 요소 및 노드 자체를 삭제합니다. 
// removeChild() : 선택된 요소 및 노드의 자식 노드를 삭제합니다.

// *부모노드를 찾는 프로퍼티(= 속성)
// 자식노드.parentNode => 해당 자식노드의 부모노드를 찾습니다.
// document.querySelector("h1").parentNode;


// 부모노드.removeChild(자녀노드);

//미션 답안
// const liList = document.querySelectorAll("li");

// liList.addEventListener("click", () => {
//   liList.remove()
// });

//강사님 답안
// const items = document.querySelectorAll("li");

// for(let item of items) {
//   item.addEventListener("click", function() {
//     this.parentNode.removeChild(this);
//   });
// };

// 화살표 함수가 만능이 아니다.
// 화살표함수는 여러개의 복수선택 해야하는 경우에는 쓰면안된다.
// this객체 : 그때그때 가르키는게 다르다
// this객체 : 선택지가 복수의 경우, 사용자가 뭘 선택할지 모를때, 화살표함수를 썻을때 this객체를 쓰면 window객체를 가르킨다
// this객체를 쓸때는 클레식 함수를 써야한다.

// 미션 내답안
// p로 잡은경우
// const items = document.querySelectorAll("p");

// for(let item of items) {
//   item.addEventListener("click", function() {
//     this.parentNode.removeChild(this);
//   });
// };

// 미션 강사님 답안
// span으로 잡은 경우
// const buttons = document.querySelectorAll("span")

// for(let button of buttons) {
//   button.addEventListener("click", function() {
//     this.parentNode.remove(this)
//   });
// };
// for of : 배열객체에서 한놈씩 잡아올때 
