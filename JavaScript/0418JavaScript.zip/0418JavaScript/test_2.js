// const btn = document.querySelector("#btn");
// const result = document.querySelector("#result");

// let li = document.createElement("li");


// btn.addEventListener("click", () => {
//   setInterval(result.appendChild(li), 1000);
// })

const btn = document.querySelector("#btn");
const notiBox = document.querySelector("#noti-box");

btn.addEventListener("click", () => {
  const noti = document.createElement('div');
  noti.classList.add('noti');
  noti.innerText = "항상 응원합니다!";
  notiBox.appendChild(noti);

  setTimeout(() => {
    noti.remove();
  }, 2000);
});