// 1. 이름 및 전공 데이터 보관 / 내용 정의값
// 2. 등록하기 버튼 기능 정의
// 3. 내용 출력공간 정의

let userName = document.querySelector("#userName");
let major = document.querySelector("#major");
const btn = document.querySelector("button");

btn.addEventListener("click", (e) => {
  e.preventDefault();

  let tbody = document.querySelector("tbody");
  let newTr = document.createElement("tr");

  let nameTd = document.createElement("td");
  nameTd.innerText = userName.value;
  userName.value = "";

  let majorTd = document.createElement("td");
  majorTd.innerText = major.value;
  major.value = "";
  
  newTr.appendChild(nameTd);
  newTr.appendChild(majorTd);

  tbody.appendChild(newTr);
});