// 오전/오후 시간에 따라 바뀌는 이미지 만들기
// 1. 시간(*오전 / 오후)에 대한 개념 정의
// 2. 시간 변화에 따라서 출력해줘야하는 이미지가 어떤것인지에 대한 정의
// > 시간 변화 정의 - 이미지 정의
// 3. 이미지를 출력할 공간에 대한 정의

const container = document.querySelector("#container");
const today = new Date();
const hrs = today.getHours();

let newImg = document.createElement("img");
newImg.src = (hrs < 12) ? "/img/morning.jpg" : "/img/afternoon.jpg";
container.appendChild(newImg);

