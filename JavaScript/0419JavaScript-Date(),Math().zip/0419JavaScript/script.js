// ##팝업 만들기 1
// window.open("popup.html","popup1" ,"width=500, height=500, left=50, top=20");

// ##팝업 만들기 2
// window.open("popup.html", "이벤트팝업", "width=600 heigth=500 left=300 top=200")

//##팝업창 만들기-3
// const btn = document.querySelector("button");
// const popWidth = 600;
// const popHeight = 500;

// btn.addEventListener("click", () => {
//   // screen.availWidth, screen.availHeight 가용할수있는 값
//   // 나누기 2를 하면 상하좌우에 값을 나눠가지겠다라는 뜻
//   //가운데에 가져오기 위해서
//   let left = (screen.availWidth - popWidth) / 2;
//   let top = (screen.availHeight - popHeight) / 2;

//   // 팝업이미지위치, 팝업 명, 너비,높이,왼쪽,위
//   window.open("popup.html", "pop1", `width=${popWidth} height=${popHeight} left=${left} top=${top}`);
// });

// ## 디바이스에 따른 화면 전환 -4 
// let info = navigator.userAgent.toLowerCase();
// let osImg = null;

// if(info.indexOf(`windows`) >= 0) {
//   osImg = `windows.png`;
// } else if (info.indexOf(`macintosh`) >= 0) {
//   osImg = `macintosh.png`;
// } else if (info.indexOf(`iphone`) >= 0) {
//   osImg = `iphone.png`;
// } else if(info.indexOf(`android`) >= 0) {
//   osImg = `android.png`;
// }

// document.write("<img src=\"/img/"+ osImg +"\">", "<br />");
// let scr = screen;
// let sc_w = scr.width;
// let sc_h = scr.height;

// document.write("모니터 해상도 너비:" + sc_w + "px", "<br />");
// document.write("모니터 해상도 높이:" + sc_h + "px", "<br />");

// 내장객체

// window 객체
// window 객체 : pageX / .pageY : 화면상에 마우스가 이동했을 때의 키값을 반환하는 프로퍼티
// - 하위객체 - 
// > 11 screen 객체 :프로퍼티 .innerWidth / .width
// > 22 navigator 객체 :프로퍼티 .userAgent
// > ## location 객체 :프로퍼티 .reload()

// Date 객체 : 현시점의 년도, 월, 일, 날짜, 요일, 시간 등을 사용하고자 할 때 이용하는 내장객체
// > 내장되어 있는 Date 객체를 사용하는 방법 : let today = new Date()
// > let 참조변수 = 키워드(new) Date()
// 프로토타입 / 인스턴스
// 프로토타입 : 자주 사용하는 기능을 객체로 만들어 놓은 것
// 인스턴스 : 프로토타입으로 만든 객체

// 자바스크립트 시간에 대한 세계관
// 1초 = 1000밀리초

// 1분 = 60 * 1000밀리초

// 1시간 = 60 * 60 * 1000밀리초

// 1일 = 24 * 60 * 60 * 1000밀리초

// toDateString() : Date에서 날짜 부분만 표시할때
// toTimeString() : Date에서 시간 부분만 표시할때

// get = 시간을 가져올때
// set = 시간을 세팅할때

// 특정 날짜 데이터를 사용하고자 할 때, 월(month)의 값은 1이 아닌, 0에서 시작합니다.Date에서
// 4월 : 3월
// 1월  ~ 12월 

// > ##location 객체 :프로퍼티 .reload()-5
// 일치하지 않는 값을 넣더라도 새로고침으로 돌아간다
// 사용 예시
// let id = "today";
// let pw = 1234;

// let user_id = prompt("당신의 아이디는?");
// //primpt() 앞의 window는 생략가능

// if (id == user_id) {
//   let user_pw = parseInt(prompt("당신의 비밀 번호는?"));

//   if (pw == user_pw) {
//     document.write(user_id + "님 반갑습니다!");
//   } else {
//     alert("비밀번호가 일치하지 않습니다!");
//     location.reload();
//   }
// }  else {
//   alert("아이디가 일치하지 않습니다!");
//   location.reload();
// }

// <!-- #### window 객체 : pageX / .pageY -->
// jQuery로 사용
// let pointSize = $(".pointer").width();
// $("#wrap").mousemove(function(e) {
//   $(".pointer").css("top", e.pageY-pointSize);
//   $(".pointer").css("left", e.pageX-pointSize);
//   $(".pointer").fadeIn();
// });

// $("#wrap").on("mouseleave", function() {
//   $(".pointer").fadeOut();
// });


// #### 내장객체 Date() 사용예시
// let today = new Date();
// let nowMonth = today.getMonth() + 1;
// let nowDate = today.getDate();
// let nowDay = today.getDay();

// document.write("<h1>오늘 날짜 정보</h1>");
// document.write("현재 월: " + nowMonth, "<br />");
// document.write("현재 일: " + nowDate, "<br />");

// let classOpen = new Date("2023-02-28");
// // 날짜 쓰는 방법
// // let classOpen = new Date("2023,02,28");
// // let classOpen = new Date("02/28/2023");
// let theMonth = classOpen.getMonth() + 1;
// let theDate = classOpen.getDate();

// document.write("<h1>개강일 날짜 정보</h1>");
// document.write("개강 월: " + theMonth, "<br />");
// document.write("개강 일: " + theDate, "<br />");


// #### 내장객체 Date() 사용예시-2
// let today = new Date();
// let nowYear = today.getFullYear();

// let theDate = new Date(nowYear, 11, 31);
// // 월의 값은 인덱스값을 가져와야 정상적으로 작동한다
// let diffDate = theDate.getTime() - today.getTime();

// // ceil() 소수점 첫번째 올려라
// let result = Math.ceil(diffDate / (60 * 60 * 24 * 1000));
// document.write("연말 D-day: " + result + "일 남았습니다");


// ####내장객체 Date() 사용예시-3 D-day 계산기
// let now = new Date();
// let toNow = now.getTime();

// let firstDay = new Date("2023-02-28");
// let toFirst = firstDay.getTime();

// let passedTime = toNow - toFirst;
// let passedDay = Math.round(passedTime / (24 * 60 * 60 * 1000));
// document.querySelector("#accent").innerText = passedDay + "일";

//   /* D-100 */
//   let future = toFirst + 100*(24 * 60 * 60 * 1000);
//   let someDay = new Date(future);
//   let year = someDay.getFullYear();
//   let month = someDay.getMonth() + 1;
//   let date = someDay.getDate();
//   document.querySelector("#date100").innerText = year + "년" + month + "월" + date + "일"

// function calcDate(e) {
// let future = toFirst + e*(24 * 60 * 60 * 1000);
// let someDay = new Date(future);
// let year = someDay.getFullYear();
// let month = someDay.getMonth() + 1;
// let date = someDay.getDate();
// document.querySelector("#date"+e).innerText = year + "년" + month + "월" + date + "일"
// }

// calcDate(100);
// calcDate(200);
// calcDate(365);
// calcDate(500);

// ### 디지털 시계
// const hour = document.querySelector(".hour");
// const min = document.querySelector(".min");
// const sec = document.querySelector(".sec");

// function clock() {
//   const now = new Date();

//   hour.innerText = now.getHours();
//   min.innerText = now.getMinutes();
//   sec.innerText = now.getSeconds();
// }

// setInterval(clock, 1000);
// // 시간간격으로 동일한 행동

// ### 아날로그 시계
// setInterval(() => {
//   const now = new Date();

// const h = now.getHours();
// const m = now.getMinutes();
// const s = now.getSeconds();

// const degH = h * (360 / 12) + m * (360 / 12 / 60);
// const degM = m * (360 / 60);
// const degS = s * (360 / 60); 

// const elementH = document.querySelector(".lineHour");
// const elementM = document.querySelector(".lineMin");
// const elementS = document.querySelector(".lineSec");

// elementH.style.transform = `rotate(${degH}deg)`
// elementM.style.transform = `rotate(${degM}deg)`
// elementS.style.transform = `rotate(${degS}deg)`
// }, 1000);

// #### 만보 걷기
// const today = new Date();
// const firstDay = new Date("2023-02-28");
// const result= document.querySelector("#result");

// let passedTime = today.getTime() - firstDay.getTime();
// let passedDay = Math.round(passedTime / (1000 * 60 * 60 * 24));

// result.innerText = passedDay

// #### 디지털 시계 ver.2
// const today = new Date();

// const displayDate = document.querySelector("#today");

// const year = today.getFullYear();
// // getMonth()는 +1을 꼭해줘야 한다
// const month = today.getMonth() + 1;
// const date = today.getDate();
// const day1 = today.getDay();

// let day2 = " ";

// switch(day1) {
//   case 0 :
//     day2 = "일요일"; break
//   case 1 :
//     day2 = "월요일"; break
//   case 2 :
//     day2 = "화요일"; break
//   case 3 :
//     day2 = "수요일"; break
//   case 4 :
//     day2 = "목요일"; break
//   case 5 :
//     day2 = "금요일"; break
//   case 6 :
//     day2 = "토요일"; break
//   }

// displayDate.innerHTML = `${year}년 ${month}월 ${date}일 ${day2}`

// const displayTime = document.querySelector("#clock");

// // 방법 1
// // setInterval(() => {

// // }, 1000)

// // 방법2 콜백함수
// // let clock = () => {

// // }
// // setInterval(clock, 1000)

// let clock = () => {
//   let current = new Date();
//   let hrs = current.getHours();
//   let mins = current.getMinutes();
//   let secs = current.getSeconds();

//   // 하루는 24시 (0시 ~ 23시)
//   // 16시 - 12시 = 4시
//   // 23시 59분 59초 => 12시
//   let period = "AM";
//   if (hrs == 0) {
//     hrs = 12;
//   } else if (hrs > 12) {
//     hrs = hrs - 12;
//     period = "PM"
//   }

//   // 삼항조건 연산자
//   hrs = (hrs < 10) ? "0" + hrs : hrs
//   mins = (mins < 10) ? "0" + mins : mins
//   secs = (secs < 10) ? "0" + secs : secs
//   displayTime.innerText = `${period} ${hrs} : ${mins} : ${secs}`
// }
// setInterval(clock, 1000);

// 수학객체 시작하는 부분

// #### 수학객체 
// let num = 2.1234

// // max() 최댓값 반환
// let maxNum = Math.max(10, 5, 8, 30);
// // min() 최소값 반환
// let minNum = Math.min(10, 5, 8, 30);
// // 반올림 메서드
// let roundNum = Math.round(num);
// // 소수점 첫번째 자리를 버린다(내린다), 어떤값이 와도
// let floorNum = Math.floor(num);
// // 소수점 첫번째 자리를 올린다, 어떤값이 와도
// let ceilNum = Math.ceil(num);
// // 랜덤값, 1이 절대 넘어가지 않는다
// // 난수값을 실수로 가져온다. 새로고침할때 마다 값이 바뀐다
// let rndNum = Math.random();
// // 파이, 원주율
// let piNum = Math.PI;

// document.write(maxNum, "<br />");
// document.write(minNum, "<br />");
// document.write(roundNum, "<br />");
// document.write(floorNum, "<br />");
// document.write(ceilNum, "<br />");
// document.write(rndNum, "<br />");
// document.write(piNum, "<br />");

// #### 수학객체 예제 1
// length 배열객체의 총 개수
// 인덱스 번호 = 0부터 시작함
// let menu = ["짜장밥", "돈까스", "국밥", "김치찌개", "회덮밥"];
// let menuNum = Math.floor(Math.random() * menu.length);
// let result = menu[menuNum]
// document.write(result)

// #### 컴퓨터와 가위,바위,보 게임 만들기
// let game = prompt("가위, 바위, 보 중 선택하세요", "가위");
// let gameNum;
// switch (game) {
//   case "가위" : 
//   gameNum = 1; break;
//   case "바위" : 
//   gameNum = 2; break;
//   case "보" : 
//   gameNum = 3; break;
//   default : alert("잘못 작성했습니다.");
//   location.reload();
// }

// // 가위, 바위, 보 중 3가지 
// let com = Math.ceil(Math.random()*3);
// document.write("<img src=\"/img/math_img_" + com + ".jpg\">");

// if (gameNum == com) {
//   document.write(`<img src=\"/img/game_1.jpg\">`)
// } else {
//   document.write(`<img src=\"/img/game_2.jpg\">`)
// }


