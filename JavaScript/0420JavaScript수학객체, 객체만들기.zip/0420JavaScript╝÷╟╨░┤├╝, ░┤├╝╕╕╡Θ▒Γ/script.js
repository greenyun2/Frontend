// // #### Math()객체 가위,바위,보 게임 만들기
// // 1. 버튼에 대한 정의가 필요(*가위 바위 보에 따라서 어떠한 값을 부여할 것인가?)
// // 2. 컴퓨터 선택에 대한 정의(*Math 객체를 활용해서 값을 부여)
// // 3. 컴퓨터와 사용자 선택값에 대한 우열을 가릴수 있는 조건식 정의
// // 4. 컴퓨터와 사용자 선택값에 따른 결과를 출력할 공간에 대한 정의

// // 어떤 버튼이 선택될지 모르기 때문에 All
// const buttons = document.querySelectorAll("button");
// const computerChoice = document.querySelector(".computer-choice");
// const userChoice = document.querySelector(".you-choice");
// const winner = document.querySelector(".result");
// const result = ["가위", "바위", "보"];

// const show = (user, computer, result) => {
//   computerChoice.innerText = computer;
//   userChoice.innerText = user;
//   winner.innerText = result;
// } 

// const game = (user, computer) => {
//   if (user == computer) {
//     message = "무승부!"
//   } else {
//     switch (user + computer) {
//       case "가위보" : 
//       case "바위가위" :
//       case "보바위" : 
//       message = "사용자 승리!"
//         break;
//         case "가위바위" :
//         case "바위보" :
//         case "보가위" :
//           message = "컴퓨터 승리!"
//           break;
//     }
//   }

//   show(user, computer, message);
// };

// const play = (event) => {
//   //target 이번트가 발생된 녀석
//   const user = event.target.innerText
//   // 랜덤함수는 0.9999 * 가위바위보 길이값 3을 곱하고 소수점 첫자리 버리기 = 0 ~ 2(인덱스값을 활용해야 하기 때문)
//   const randomIndex = Math.floor(Math.random() * result.length)
//   const computer = result[randomIndex];
//   game(user, computer)
// }

// // 버튼들중 어떤 버튼이 선택된다면 이벤트를 주겠다
// buttons.forEach((button) => {
//   button.addEventListener("click", play)
// });

// ### 원 넓이, 둘레 구하기
// 원 넓이 구하는 공식 : 반지름 * 반지름 * 원주율
// 원 둘레 구하는 공식 : 반지금 * 2 * 원주율

// 1. 결과값을 출력해야하는 공간 정의
// 2. 원의 넓이를 구하는 공식에 대한 정의 (*함수)
// 3. 원의 둘레를 구하는 공식에 대한 정의
// 4. 반지름 => 사용자로부터 값을 받을 예정

// const result = document.querySelector("#result");
// const radius = prompt("반지름의 크기는?");

// // 원의 넓이를 구하는 함수
// function area(r) {
//   // r = 반지름 매갭변수
//  return Math.PI * r * r
// };
// // undefined가 나오는 이유는 함수에 값을 반환해주지 않았기 때문 return을 써주자

// // 원의 둘레를 구하는 함수
// function circum(r) {
//    // r = 반지름
//    return Math.PI * r * 2
// };
// // undefined가 나오는 이유는 함수에 값을 반환해주지 않았기 때문 return을 써주자

// // 출력하는 공간
// result.innerText = `
//   반지름 : ${radius},
//   원의 넓이 : ${Math.round(area(radius))},
//   원의 둘레 : ${circum(radius).toFixed(3)}
// `;
// toFixed(소수점 자리) 원하는 소수점자리 까지만 보여줘
// Math.round() 반올림


// #### 새로고침시 이미지 바뀜 내 답안 ## 스크립트만 작성
// 1. 이미지에 대한 정의
// 2. 이미지가 보여질 공간의 정의
// 3. Math.random()를 이용한다
// 4. Math.random()은 0.9999...
// const body = document.querySelector("body");

// setInterval(() => {
//   let img = ["bg-1","bg-2","bg-3","bg-4","bg-5"];
//   let imgNum = Math.floor(Math.random() * img.length);
//   let result = img[imgNum];
//   body.innerHTML = (`<img src=\"/img/${result}.jpg\">`);
// }, 1000);

// #### 새로고침시 이미지 바뀜 강사님 답안
// * 우리에게 필요한 것!!!
// 1. 출력할 공간 정의
// 2. 출력할 요소(*컨텐츠)에 대한 정의

// 방법-1
// const changeBg = () => {
//   const bgCount = 5;
//   // ceil() 사용시 올림이니까 1~5 가 된다
//   let randomNumber = Math.ceil(Math.random() * bgCount)
//   document.body.style.backgroundImage = `url(img/bg-${randomNumber}.jpg)`
// }
// document.onload = changeBg();

// 방법-2
// window.onload = () => {
//   const bgCount = 5
//   let randomNumber = Math.ceil(Math.random() * bgCount);

//   document.body.style.backgroundImage = `url(img/bg-${randomNumber}.jpg)`
// }

// #### 내가 살아온 시간 계산기
// #### 내가 작성한 답안 ######################
// 1. 시간의 정의 = 현재
// 2. 과거부터 현재까지의 시간
// 3. 날짜의 데이터
// 4. 시간의 데이터
// const year = document.querySelector("#year")
// const month = document.querySelector("#month")
// const date = document.querySelector("#date")
//   let now = new Date();
//   year.innerText = now.getFullYear;
//   month.innerText = now.getMonth + 1;
//   date.innerText = now.getDate;
// let now = new Date();
// let nowYear = now.getFullYear
// let nowMonth = now.getMonth + 1
// let nowDate = now.getDate
// let nowDay = now.getDay
// const day = document.querySelector("#current").innerText =
// nowYear + "년"
// // 1. 현재 년, 월, 일 데이터 받아오기
// let now = new Date();
// let year = now.getFullYear()
// let month = now.getMonth() + 1
// let date = now.getDate()
// let time = now.getTime() / (24 * 60 * 60 * 1000)
// const current = document.querySelector("#current")
// current.innerHTML = year + "년" + month + "월" + date + "일" + time
// #### 내가 작성한 답안 ######################

// ####@@@@ 강사님 답안

// 1. 계산 이라는 버튼에 대한 기능 정의
// 2. 사용자로 부터 값을 입력받고 저장할 수 있는 공간에 대한 정의
// 3. 원하는 갑을 출력해야하는 공간에 대한 정의
// 4. 출력할 값에 대한 수식 정의

// const birthYear = document.querySelector("#year");
// const birthMonth = document.querySelector("#month");
// const birthDate = document.querySelector("#date");
// const btn = document.querySelector("button");

// const current = document.querySelector("#current");
// const resultDays = document.querySelector("#days");
// const resultHours = document.querySelector("#hours");
// const resultYears = document.querySelector("#years");

// const today = new Date();
// current.innerText = `현재시간 ${today.getFullYear()}년 ${today.getMonth()+1}월 ${today.getDate()}일 ${today.getHours()}시 ${today.getMinutes()}분`

// btn.addEventListener("click", (e) => {
//   e.preventDefault();
//   const birthDay = new Date(birthYear.value, birthMonth.value - 1, birthDate.value);

//   let passed = today.getTime() - birthDay.getTime();
//   let passedYears = Math.floor(passed / (1000 * 60 * 60 * 24 * 365));
//   let passedDays = Math.floor(passed / (1000 * 60 * 60 * 24));
//   let passeHours = Math.floor(passed / (1000 * 60 * 60));

//   resultYears.innerText = ` 년으로는 ${passedYears} 년이 흘렀습니다.`
//   resultDays.innerText = ` 날짜로는 ${passedDays} 일이 흘렀습니다.`
//   resultHours.innerText = ` 시간으로는 ${passeHours} 시간이 흘렀습니다.`

//   birthYear.value = "";
//   birthMonth.value = "";
//   birthDate.value = "";
// });

// #### 당첨자 발표 만들기
// 1. 추첨 및 지우기 버튼의 대한 기능 정의
// 2. 입력한 값에 대한 저장공간 및 활용에 대한 정의
// 3. 입력한 값을 출력할 공간에 대한 정의
// 4. 출력할 값에 대한 조건 및 논리구조 정의

// const raffle = document.querySelector("#raffle");

// raffle.addEventListener("click", (e) => {
//   e.preventDefault();
//   const seed = document.querySelector("#seed");
//   const total = document.querySelector("#total");
//   const result = document.querySelector("#result");
//   let winner = "";

//   for(let i = 0; i < total.value; i++) {
//     let picked = Math.ceil(Math.random() * seed.value);
//     winner += `${picked}번, `;
//   }

//   result.innerText = `당첨자 : ${winner}`;
  
// });

// #### 자바스크립트 객체 만들기!!!
// - 내장객체 : 
// Date(), Math()

// 객체란 : 
// - 프로그램에서 인식할 수 있는 모든 대상
// - 여러개의 데이터를 하나로 묶어놓은 대상
// - 예시)
// > "회원"객체 
// - 나이 : 29
// -성별 : 남 / 녀
// -사는곳 : 서울 / 경기

// document.querySelector => DOM (문서 객체 모델)
// window.onload => BOM (브라우저 객체 모델)
// window.body => BOM (브라우저 객체 모델)

// 개발자가 직접 정의할 수 있는 사용자 정의 객체 만들기!!!

// 객체의 형태!!!!

// 객체명 {
//   key : value, => 이런식으로 한쌍이 돼있는걸 프로퍼티
// }

// 객체 만들기와 객체의 중첩, 객체의 메서드 만들기-1
// let student = {
//   name : "Park",
//   // 객체의 중첩
//   score : {
//     history : 85,
//     science : 94,
//     // 메서드 만들기-1
//     average : function() {
//       return (this.history + this.science) / 2
//     }
//   }
// }

// 객체의 메서드를 만드는 방법-2
// let book3 = {
//   title : "파이썬",
//   pages : 360,
//   buy() {
//     console.log("이 책을 구입했습니다!");
//   }
// }

// let book4 = {
//   title : "JavaScript",
//   pages : 500,
//   author : "곽두팔",
//   done : ture,
//   finish : function() {
//     this.done == false ? console.log("읽는 중") : console.log("완독");
//   }
// }

// let beg1 = {
//   color : "blue",
//   width : 30,
//   height : 50
// };
// beg1
// let beg2 = beg1
// beg2.color = "red"
// beg2
// beg1

// #변수의 재할당과 객체의 재할당의 차이
// 객체는 윈시데이터가 아니라 참조 주소를 복사 하기 때문에
// 객체는 재할당시 원본 객체의 값도 바뀐다

// 변수 : 원시값을 복사한다
// 객체 : 참조 주소를 복사한다

// 동일한 key & value 값을 가지고 있는 프로퍼티와 메서드 객체를 
// 만약 100개를 만들어야 한다면?
// // 객체를 복제 할때
// this객체 쓰기 (화살표 함수를 쓸때는 this객체를 쓰지않는다.)

// > 생성자 함수!!!! => 붕어빵 틀
// = 동일한 프로퍼티 및 메서드를 가지고 있는 객체를 만들때 사용할수 있는 함수

// 인스턴스 객체!!!! => 붕어빵 틀에서 나온 붕어빵
// = 생성자 함수를 통해서 만들어진 복제된 객체
// 예시) 
// let today = new Date();
// 인스턴스 객체 new라는 키워드를 씁니다
// Date() 라는 생성자 함수가 있기 때문에 인스턴스 객체를 만들수 있다

// #생성자 함수를 만드는 방법 = 함수는 함수인데, 복제품을 만드는 함수
// function Book(매개변수1, 매개변수2, ...) {
//   this.매개변수1 = 매개변수1
//   this.매개변수2 = 매개변수2

//   this.메서드1 : function() {...}
//   this.메서드2 : function() {...}
// }
// // 익명함수로 작성하는 방법
// const 함수명(매개변수) = function(){...}

// 생성자 함수가 무엇인지, 생성자 함수가 왜 필요한지, 인스턴스가 무엇인지
// 생성자 함수
// function Book(title, pages, done) {
//   this.title = title;
//   this.pages = pages;
//   this.done = done;
//   this.finish = function() {
//     let str = "";
//     this.done == false ? str = "읽는중" : str = "완독";
//     return str;
//   }
// }

// // // 생성자 함수의 내용을 정의했기 때문에 쓸수있다 (인스턴스 객체)
// let book1 = new Book("파이썬", 648, false);
// let book2 = new Book("자바스크립트", 360, true);

// document.write(`${book1.title} - ${book1.pages}쪽 - ${book1.finish()} <br />`)
// document.write(`${book2.title} - ${book2.pages}쪽 - ${book2.finish()}`);

// 프론트엔드 영역은 언어의 변화 속도 및 업그레이드가 매우 빠르다.

// > 생성자 함수와 다른 방법 Class
// > ##자바스크립트의 클래스를 활용한 객체 생성 방법

// class 클래스명 {
//   constructor(매개변수1, 매개변수2,등등..) {
//     프로퍼티1,
//     프로퍼티2,
//   }
//   메서드1() {}
//   메서드2() {}
// }

// #### 클래스를 활용한 객체 생성 방법 예시
// class Book2 {
//   constructor(title, pages, done) {
//     // 프로퍼티와 매개변수는 꼭 매칭해줘야한다
//     this.title = title;
//     this.pages = pages;
//     this.done = done;
//   }
//   finish() {
//     let str = "";
//     this.done == false ? str = "읽는중" : str = "완독";
//     return str;
//   }
// }

// let book1 = new Book2("파이썬", 348, false);
// let book2 = new Book2("자바스크립트", 620, true);

// document.write(`${book1.title} - ${book1.pages}쪽 - ${book1.finish()} <br />`)
// document.write(`${book2.title} - ${book2.pages}쪽 - ${book2.finish()} <br />`)


// ####윈기둥의 부피 구하기
// 1. 계산하기 버튼에 대한 기능정의!
// 2. 사용자가 입력하는 지름 및 높이 값에 저장공간 정의
// 3. 원기둥의 부피를 구하는 계산식에 대한 정의
// 4. 계산후 결과값을 출력할 공간에 대한 정의


// @@@@ 생성자 함수를 활용한 객체 생성
// function Cylinder(cylinderDiameter, cylinderHeight) {
//   this.diameter = cylinderDiameter;
//   this.height = cylinderHeight;

//   this.volume = function() {
//     let radius = this.diameter / 2;
//     return (Math.PI * radius * radius * this.height).toFixed(1);
//   };
// };

// @@@@ 클래스를 활용한 객체 생성
// class Cylinder {
//   constructor(cylinderDiameter, cylinderHeight) {
//     this.diameter = cylinderDiameter;
//     this.height = cylinderHeight;
//   }
//   volume() {
//       let radius = this.diameter / 2;
//     return (Math.PI * radius * radius * this.height).toFixed(1);
//   }
// }

// const button = document.querySelector("button");
// const result = document.querySelector("#result");

// button.addEventListener("click", function(e) {
//   e.preventDefault();
//   const diameter = document.querySelector("#cyl-diameter").value;
//   const height = document.querySelector("#cyl-height").value;

//   if (diameter == "" || height == "") {
//     result.innerText = `지름과 높이값을 입력하세요!`;
//   } else {
//     let cylinder = new Cylinder(diameter, height);
//     result.innerText = `원기둥의 부피는 ${cylinder.volume()}입니다.`;
//   }
// });













