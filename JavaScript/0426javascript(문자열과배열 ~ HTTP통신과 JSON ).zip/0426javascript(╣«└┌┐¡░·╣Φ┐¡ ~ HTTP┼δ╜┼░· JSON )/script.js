// 문자열 & 배열!!!

// let numbers = [1, 2, 3, 4, 5];
// 배열객체에서 숫자열을 사용할땐 큰따옴표를 사용하지 않는다
// 배열 => 순서 / 중간 요소 수정.편집 가능

// 배열을 변형하는 메서드 함수

// 1) Map() : 배열 요소에 동일한 함수를 적용하고자 할 때
// 사용방법 : 
// - Map(함수(값))
// - Map(함수(값, 인덱스))

// 2) filter() : 배열 요소에 특정한 조건식을 부여해서 해당 값을 추출하고자 할때
//               필터링한다
// 사용방법 :
// - filter(함수(값))
// - filter(함수(값, 인덱스))

// 3) reduce() : 배열 요소에 특정 콜백함수를 실행해서 최종적인 하나의 결과값을 만들어낼 때 
// 사용방법 : 
// - reduce(함수(누산기, 현재값, 인덱스, 원래배열), 초기값)
// 필수입력사항 : 누산기, 현재값
// 비필수입력사항 이지만 입력권장 : 초기값


// Map & Set
// > 객체와 배열의 좋은 점만 추출한 자료형태

// 객체의 단점 : 
// 1) 객체의 프로퍼티 순서가 존재하지 않습니다 > for문을 활용해서 특정 구간을 반복하는데 어려움 혹은 제약이 존재
// 2) 객체는 프로퍼티의 개수를 알려주는 속성값이 없습니다.

// 객체와 배열의 혼합

// let myCup = new Map([
//   [ "color", "white"],
//   ["haveHandle", true],
//   ["material", "ceramic"],
//   ["capacity", "300ml"]
// ]);

// Map 데이터 자료형에서 사용할 수 있는 프로퍼티와 메서드
// size : 맵 요소의 개수를 알려주는 프로퍼티
// set(key, value)을 추가해주는 메서드
// get(키) 해당 맵의 키 값을 반환하는 메서드
// has(키) 해당 키가 맵에 있는지 여부에 따라서 ture 혹은 false값을 반환해주는 메서드
// delete(키) 해당 키가 존재하는 프로퍼티를 삭제
// clear() 맵의 모든 요소를 삭제
// keys() 각 요소의 키만 모아서 반환
// values()  각 요소의 값만 모아서 반환
// entries() 각 요소의 키와 값을 반환

// 이터러블 = Iterable : 순서대로 처리할 수 있는

// Map 단점 : Map데이터 안에 들어가는 요소가 중복이 되더라도 문제가 되지 않습니다
// 보완하기 위해 나온 set 
// set : 값이 중복될 수 없는 엄격한 자료 관리가능!

// set은 중복된 값을 허용하지 않는다
// let lang = new Set(["js", "c", "pyton", "c", "js"]);
// for (let el of lang.values()) {
//   console.log(el)
// }

// #### 중복되지 않는 신청과목 만들기
// const member1 = ["HTML", "CSS"];
// const member2 = ["CSS", "JavaScript", "React"];
// const member3 = ["JavaScript", "TypeScript"];

// // 배열객체를 하나로 모을수있는 방법: 전개연산자
// const subjects = [...member1, ...member2, ...member3];
// // console.log(subjects); 값 확인

// // 중복되지 않게 값을 추출 Set()
// const resultList = new Set();
// subjects.forEach(subject => {
//   resultList.add(subject);
// });
// // 중복되지 않는지 확인
// // console.log(resultList)

// const result = document.querySelector("#result");
// // innerText를 사용하지 않는 이유는 ul태그를 만들기 위해서
// result.innerHTML = `
//   <ul>
//   ${[...resultList]
//     .map(subject => `<li>${subject}</li>`)
//     .join("")
//   }
//   </ul>
// `
// 전개연산자 [...배열객체] 전개연산자를 사용하면 원본데이터의 회손없이 값을 복제할수있다
// 배열객체 => 값을 복제할때, 
// 1) 원시유형 데이터 x => 객체이기 때문에
// 2) 주소 복사 데이터 o => 원본데이터도 바뀐다
// 원본데이터를 바꾸지 않고 값을 복제하고 싶을때
// join() 배열을 문자열로 전환할때

// 미션1 복습 #########################################
// const member1 = ["HTML", "CSS"];
// const member2 = ["CSS", "JavaScript", "React"];
// const member3 = ["JavaScript", "TypeScript"];

// const subjects = [...member1, ...member2, ...member3];
// // console.log(subjects)

// const resultList = new Set();
// subjects.forEach(subject => {
//   resultList.add(subject)
// })
// // console.log(resultList)

// const result = document.querySelector("#result");
// result.innerHTML = `
//   <ul>
//   ${[...resultList]
//     .map(subject => `<li>${subject}</li>`)
//     .join("")
//   }
//   </ul>
// `

// 미션1 복습 #########################################

// *이터레이터 & 제너레이터 함수
// 1. 문자열, 배열, Map, Set : 이터러블 객체 (iterable)
// > 이터러블 : 순서대로 처리할 수 있는
// > 이터러블 객체의 특징 :
// > 이터레이터 객체를 프로토타입으로 상속을 받아야지만, 이터러블 객체가 될 수 있다.
// 이터레이터 객체는 > next()메서드를 가지고 있다
// : 이터러블 객체 = 문자열, 배열 
// 모든 문자열과 배열 안에서 next()의 역할은 
// > 처음 실행했을 때에는 인덱스 첫번째 값을 호출하고, next()를 한번 더 실행하면 그 다음 인덱스 값을 호출한다.
// 어떤 값을 호출할때, 한번에 값을 호출하지 않고, 순차적으로 값을 호출하고 싶을 때, 그때 next()메서드를 사용한다

// 생성자 함수!! => 동일한 프로퍼티 혹은 객체를 다수 생성하고자 할 때, 템플릿을 만들어 놓고, 해당 템플릿을 통해서 효율적으로 객체를 만들고 싶기 때문에

// 제너레이터 함수의 모습
// function* 함수명() {
//   yield 1; // yield key값 
//   yield 2;
//   yield 3;
//   yield 4;
// }

// #### 경강선 노선 만들기
// 제너레이터 함수를 이용하기
// function* train() {
//   yield "판교";
//   yield "이매";
//   yield "삼동";
//   yield "경기광주";
//   yield "초월";
//   yield "곤지암";
//   yield "신둔도예촌";
//   yield "이천";
//   yield "부발";
//   yield "세종대왕릉";
//   yield "여주";
// }
// // 경강이라는 변수안에 제너레이터 함수 할당
// let gyeongGang = train();

// const button = document.querySelector("button");
// const result = document.querySelector("#result");

// button.addEventListener("click", () => {
//   //gyeongGang변수값 로테이션이 되게끔 만들기
//   let current = gyeongGang.next();
//   // 값이 전부다 반환되면 done값이 ture
//   // 값이 전부다 반환되기 전까지만 값을 반환
//   if(current.done !== true) {
//     result.innerText = current.value;
//   } else {
//     // 값이 전부다 반환되서 done 값이 ture값이 나오면 
//     result.innerText = "종점!"
//     // 종점이 나오면 버튼이 더이상 작동하지 않게
//     button.setAttribute("disabled", "disabled")
//   }
// });

// #### 로또 번호 생성기 만들기
// const result = document.querySelector("#result");
// const button = document.querySelector("button");

// const luckyNumber = {
//   digitCount : 6,
//   maxNumber : 45
// };

// button.addEventListener("click", () => {
//   // 객체의 key와 value값을 가져올때, 구조분해할당
//   let {digitCount, maxNumber} = luckyNumber
//   // 값이 중복되지 않게 Set()을 사용한다
//   let myNumber = new Set();
//   for(let i = 0; i < digitCount; i++) {
//     myNumber.add(Math.floor(Math.random() * maxNumber) + 1);
//   }
//   // [...myNumber] 전개연산자 배열객체 원본데이터의 회손없이 값 복제
//   result.innerText = `${[...myNumber]}`;
// });

// HTTP통신과 JSON 
// 통신의 기본개념
// 클라이언트 % 서버
// > 클라이언트의 역할 :서버에 자료를 요청하는 역할
// > 서버의 역할 : 클라이언트가 요청한 자료를 회신하는 역할

// https://www.naver.com/

// http 혹은 https : 프로토콜이라고 부른다 => 통신규약
// 통신규약 => 앞으로 웹 서버에서 클라이언트가 특정 데이터를 요청한다면, 서로 약속한 데이터 형식을 가지고 요쳥할 때만 값을 
// 출력해주자!!!

// HTML : 하이퍼 텍스트 마크업 랭귀지
// HTTP : 하이퍼 텍스트 트랜스퍼 프로토콜

// 닷홈을 활용해서 호스팅서비스 : 도메인주소!!!
// HTTP 와 HTTPS 의 차이점
// S는 왜 붙는걸까? => S는 시큐리티 보안서버가 설치돼 있다

// GET방식 : 서버에 자료를 요청할때, 사이트 주소 뒤에 자료명을 붙여서 보내는 방식
// > 요청하고자 하는 자료가 공공데이터이거나 비보안문서 혹은 정보검색용 데이터 일때

// POST 방식 : 서버에 자료를 요청할 때, 요청 문자 혹은 내요잉이 도메인 주소에 나타나지 않도록, body 본문안에 담아서 전송하는 방식 

// 404 Page Not Found 는 무엇일까?
// 2xx : 성공메세지
// 4xx : 서버로부터 데이터를 받아오는데 실패
// - 404 : 문서를 찾을 수 없을 때 (*도메인 오타)
// - 401 : 문서에 접속할 권한이 없을 때
// 5xx : 서버 자체 오류가 났을때
// - 500 : 서버다운(*접속량이 급작스럽게 늘었거나)
// - 503 : 서버 자체적으로 데이터 차단


// 자바스크립트를 활용해서 외부사이트 데이터를 가져올때!!
// XML 데이터 자료형식

// JSON = JavaScript Object Notation : 
// 자바스크립트 객체 표기법

// 사용할수 있는 곳
// 자바, C, 파이썬, C++

// JSON 이 좋은 점
// 1. XML 대비 용량이 상대적으로 작다 => 빠르게 적용이 된다
// 2. 사용할 수 있는 범위가 넓다 => 자바, C, 파이썬, C++

// JSON 의 형태
// {
//   "name" : "홍길동",
//   "major" : "컴퓨터공학",
//   "grad" : 2
// }

// *객체와 JSON 의 차이점 
// - key값을 표현할 때, ""큰따옴표 여부
// - 프로퍼티 & 메서드(함수) VS JSON 은 메서드 및 함수를 넣을 수 없다

// *유의사항
// - JSON 에서 key값을 정의할 때, 무조건 "" 큰따옴표를 써야한다

// - key값을 정의할 때, 원칙적으로 띄어쓰기 가능하나, 
// 실무에서는 아무도 띄어쓰기 하지 않는다!!!!

// - JSON 에서 value값으로 문자가 온다면 당연히 ""큰따옴표로 묶어야한다

// -JSON value 값에는 또다른 문자열 혹은 배열을 가져올 수 있습니다.



// {
//   "name" : "park",
//   "major" : "computer",
//   "grad" : 2,
//   "course" : ["HTML", "CSS"]
// }


// JSON 에는 배열객체 [] 와
// JSON 안에 또 다른 JSON 을 넣을수 있다


// 배우고 있는 내용
// 1.클라이언트 / 서버
// 2. JSON / XML
// 3. JSON.stringify() : 객체 -> JSON
// 4. JSON.parse() : JSON -> 객체


// *중요
// AJAX : Asychronous Javascript And Xml
// > 비동기 자바스크립트 와 엑스엠엘
// > 비동기 <-> 동기 
// 동기 : 서버에 자료를 요청하고, 요청한 자료가
// 정상적으로 수신이 되어야지만, 페이지 전환 및 이동

// AJAX: 웹페이지가 새롭게 로딩되지 않고도 필요한 웹문서를 가져와서 보여주는 것을 AJAX
// > 자바스크립트의 비동기 데이터 처리 방식

// 웹클라이언트 & 웹브라우저 & 웹서버

// XMLHttpRequest 객체 => XHR 객체 => 내장객체
// - 프로퍼티
// - 매서드
// > open() : 어떤 방식으로 사용할지, 어떤 자료가 필요한지,
// 비동기 처리 여부 정의하는 메서드
// > send() : 앞에서 설정한 open()를 서버로 보내는 메서드

// XMLHttpRequest 객체
// 1)메서드
// -open()
// -send()

// 2)프로퍼티
// -readyState : 객체에서 서버로 자료 요청여부 및 자료도착 여부를 알수있는 프로포티
// 0 : 아직 서버한테 자료요청을 안한 상태
// 1 : 서버한테 자료를 성공적으로 요청
// 2 : 서버 요청에 대한 응답이 온 상태
// 3 : 서버에서 자료가 로딩중인 상태
// 4 : 자료 전송이 끝나고 클라이언트가 자료를 사용할 수 있는 상태

// -status: 서버와의 통신 상태
// 2xx
// 4xx
// 5xx

// - resposeText : 서버에 요청한 응답이 문자열로 저장된 형태