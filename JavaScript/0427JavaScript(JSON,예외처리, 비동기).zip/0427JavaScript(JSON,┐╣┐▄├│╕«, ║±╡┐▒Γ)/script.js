// // JSON을 화면에 출력하기
// let xhr = new XMLHttpRequest();
// // 데이터전송방식, 제이슨 파일경로
// xhr.open("GET", "student.json");
// xhr.send();

// // reaadystate, state 중간에 있는 이벤트 헨들러
// xhr.onreadystatechange = function() {
//   // reaadystate = 4 , state = 200 => 데이터가 정상적으로 작동 
//   if(xhr.readyState == 4 && xhr.status == 200) {
//     // 변수에 제이슨을 객체타입으로 담아달라
//     let students = JSON.parse(xhr.responseText);
//     renderHTML(students);
//     // document.getElementById("result").innerHTML = `
//     // <h1>${student.name}</h1>
//     // <ul><li>전공 : ${student.major}</li>
//     // <li>학년 : ${student.grade}</li>
//     // </ul>
//     // `
//   }
// }

// function renderHTML(students) {
//   let output = "";
//   for(let student of students) {
//     output += `
//     <h2>${student.name}</h2>
//     <ul>
//     <li>전공 : ${student.major}</li>
//     <li>학년 : ${student.grade}</li>
//     </ul>
//     ` 
//   }
//   document.getElementById("result").innerHTML = output;
// }

// 예외처리!!! = 오류처리!!!

// *사용자로부터 특정 숫자를 받아서 어떤 프로그램을 실행시킨다면...
// - 사용자가 숫자를 입력하지 않았을 때의 오류!

// 예외처리

// let json = '{"grade" : 3, "age" : 25}'

// try {
//   // 제이슨을 객체타입으로 받아오는 메서드함수 .parse()
//   let user = JSON.parse(json);
//   if(!user.name) {
//     throw "사용자 이름이 없습니다!";
//   }
// } catch(err) {
//   console.error(err);
// }
// console.log("끝");

// 예외처리 = 오류처리 : 프로그램에서 문제가 발생할 때를 대비해서 작업해놓은 코드

// *try문 / catch문 / throw문 => 3가지는 같이 움직인다
// - try문 : 실제 오류가 발생했을 때, 실행할 명령문을 작성하는 곳
// - catch문 : 발생한 오류의 이름 및 설명들이 들어가 있는 곳
// - throw문 : 개발자가 직접 오류 메세지를 정의할수 있는 곳

// - console.error() => 오류 메세지를 표기할 때 사용할 수 있음!!

// JSON을 활용한 상품정보 만들기
// const result = document.querySelector("#result");
// const url = "https://reqres.in/api/products/10"

// let xhr = new XMLHttpRequest();
// xhr.open('GET', url, true);
// xhr.send();

// xhr.onreadystatechange = function() {
//   if (xhr.readyState ===4 && xhr.status === 200) {
//     let product = JSON.parse(xhr.responseText);
//     console.log(product);
//     result.innerHTML = `
//     <p>상품명 : ${product.data.name}</p>
//     <p>생산년도 : ${product.data.year}년도식</p>
//     <p>색상 : ${product.data.color}색상</p>
//     `;
//   }
// }
// 10보다 작은 숫자를 입력하세요

// #### 내가 쓴거
// const result = document.querySelector("#result")
// const btn = document.querySelector("#button")
// const inp = Document.querySelector("#input")


// btn.addEventListener("click", () => {
//   try {
//     if(inp.value < 1 || inp.value > 10) {
//       alert("1부터 9까지 입력해주세요")
//     } else if (inp.value == null) {
//       alert("1부터 9까지 입력해주세요")
//     } else if(inp.value == String) {
//       alert("1부터 9까지의 숫자를 입력해주세요")
//     } else {

//     }
//   }
//   catch(err) {

//   }
// })

// #### 강사님 답안
// 출력 공간의 정의, 버튼의 정의, 값을 입력받는 곳의 정의
// const userNumber = document.querySelector("#user-number");
// const button = document.querySelector("button");
// const result = document.querySelector("#result");

// button.addEventListener("click", (e) => {
//   e.preventDefault;
//   let n = userNumber.value;
//   try {
//     if (n === "" || isNaN(n)) {
//       throw "숫자를 입력하세요!"
//     }
//     // 원하는 값의 정의
//     n = parseInt(n);
//     if (n <= 10) {
//       result.innerText = n
//     }
//     if (n > 10) {
//       throw "10보다 작은 수를 입력하세요!"
//     }
//     // catch는 어떤 조건식을 쓸필요가 없다
//   } catch(err) {
//     alert(err);
//   } finally {
//     userNumber.value = ""
//   }
// });

// 비동기 프로그래밍

// 1) 동기 처리 방식 : 프로그램 소스가 작성된 순서대로 처리를 하는 방식

// 2) 비동기 처리 방식: 프로그램 소스의 작성순서와 상관없이 처리를 할 수 있는 방식
// > AJAX : Asynchronous Javascript And Xml 

// 자바스크립트 원래 태생 = 동기처리방식





// 싱글"스레드" : "실"
// > 프로그램에서 어떠한 프로세스를 실행하는 단위를 가르킴!!
// 한번에 하나의 프로세스를 실행한다면, 단일 혹은 싱글스레드

// 멀티스레드 :
// > 한번에 여러개의 프로세스를 실행한다면, 

// 자바스크립트는 태생적으로 싱글스레드 / 동기처리방식 지원 프로그램 언어

// 콜백함수 = 자바스크립트의 비동기 처리방식을 위한 필수요소


// #### 벨로그 작성 여기서부터
// 비동기 처리방식(콜백함수) 예제
// function displayA() {
//   console.log("A");
// };

// function displayB(callback) {
//   setTimeout(() => {
//     console.log("B");
//     callback();
//   }, 2000)
// };

// function displayC() {
//   console.log("C");
// };

// displayA();
// displayB(displayC);


// function order(coffee, callback) {
//   console.log(`${coffee} 주문접수`)
//   setTimeout(() => {
//     callback(coffee)
//   },3000);
// };

// function display(result) {
//   console.log(`${result} 준비완료`);
// };

// order("아메리카노", display);

// function displayLetter() {
//   console.log("A");
//   setTimeout(() => {
//     console.log("B");
//     setTimeout(() => {
//       console.log("C");
//       setTimeout(() => {
//         console.log("D");
//         setTimeout(() => {
//           console.log("STOP!");
//         }, 1000);
//       }, 1000);
//     }, 1000);
//   }, 1000);
// }

// displayLetter();

// 프로미스 객체!!
// Promise : *무분별한 콜백함수 사용의 부작용을 최소화하기 위해서 만든 객체
// = 프로미스객체 => 매개변수 : 
// 조건값이 true일때 실행할 함수 & 조건값이 false일때 실행할 함수
// let likePizza = false;

// // 프로미스 객체는 *내장객체 매개변수는 *true값의 콜백함수 *false값의 콜백함수
// const pizza = new Promise((resolve, reject) => {
//   if (likePizza) {
//     resolve('피자를 주문합니다.👌')
//   } else {
//     reject('피자를 주문하지 않습니다.🤔')
//   }
// });

// // promise객체의 실행문
// pizza
//   .then(
//     // 인자값은 뭘써도 상관없고, 누가봐도 직관적으로 이해되게 씀
//     result => console.log(result)
//   )
//   .catch(
//     // 인자값은 뭘써도 상관없고, 누가봐도 직관적으로 이해되게 씀
//     err => console.log(err)
//   )
//   // true던 false던 상관없이 구문을 끝내라
//   .finally(
//     () => console.log('완료')
//   )

  // promise 객체의 진행 단계 (3가지)

  // 1.pending : 프라미스 객체를 만들고 대기중인 상태

  // 2.fulfilled : 프라미스 객체를 활용해서 true값에 도착한 상태

  // 3.rejected : 프라미스 객체를 활용해서 false값에 도착한 상태

  // #### 커피 준비 완료 만들기
// let coffee = prompt("어떤 커피를 주문하시겠습니다?", "아메리카노");

// const order = new Promise((resolve, reject) => {
//   if(coffee != null && coffee != "") {
//     document.querySelector(".start").innerText = `${coffee} 주문접수`;
//     setTimeout(() => {
//       resolve(coffee)
//     }, 3000)
//   } else {
//     reject("커피를 주문하지 않았습니다!🤔")
//   }
// });

// function display(coffee) {
//   document.querySelector(".end").innerText = `${coffee} 준비완료 😎`;
//   document.querySelector(".end").classList.add("active");
//   document.querySelector(".start").classList.add("done")
// }

// function showErr(err) {
//   document.querySelector(".start").innerText = err;
// }

// order
//   .then(display)
//   .catch(showErr)

// #### 콜백함수를 써서 피자를 만들어내는 프로세스
// 콜백지옥😈
// const step1 = (callback) => {
//   setTimeout(() => {
//     console.log("피자 도우 준비");
//     callback()
//   },2000);
// }

// const step2 = (callback) => {
//   setTimeout(() => {
//     console.log("토핑 완료");
//     callback()
//   },1000);
// }

// const step3 = (callback) => {
//   setTimeout(() => {
//     console.log("굽기 완료");
//     callback()
//   },2000);
// }

// console.log("피자를 주문합니다!");
// step1(function() {
//   step2(function() {
//     step3(function() {
//       console.log("피자가 준비되었습니다!")
//     });
//   });
// });

// #### 프로미스 객체를 써서 피자를 만들어내는 프로세스
// 익명함수
// const pizza = () => {
//   return new Promise((resolve, reject) => {
//     resolve("피자를 주문합니다.😈");
//   });
// }

// const step1 = (message) => {
//   console.log(message);
//   return new Promise((resolve, reject) => {
//     setTimeout(() => {
//       resolve("피자 도우 준비😈");
//     }, 3000);
//   });
// }

// const step2 = (message) => {
//   console.log(message);
//   return new Promise((resolve, reject) => {
//     setTimeout(() => {
//       resolve("토핑 완료😈");
//     }, 1000);
//   });
// }

// const step3 = (message) => {
//   console.log(message);
//   return new Promise((resolve, reject) => {
//     setTimeout(() => {
//       resolve("굽기 완료😈");
//     }, 2000);
//   });
// }

// pizza()
// // 실제 실행문
//   .then((result) => step1(result))
//   .then((result) => step2(result))
//   .then((result) => step3(result))
//   .then((result) => console.log(result))
//   .then(() => {
//     console.log("피자가 준비되었습니다.😎");
//   });

// 서버에 있는 JSON 파일을 가져올 때 사용하는 객체 이름은?
// 1) XMLHttpRequest (*프로미스 객체를 반환할 수 없습니다)
// 2) fetch (*프로미스 객체를 반환할 수 있습니다)

// 프로미스 객체에서 3단계 진행과정

// 1. 준비 : pending
// 2. 완료 : fulfilled
// 3. 거절 : rejected

// #### JSON을 화면에 출력하기 fetch 방식
// fetch('student.json')
// .then(response => response.json())
// .then(json => {
//   let output = "";
//   json.forEach(student => {
//     output += `
//     <h2>${student.name}</h2>
//     <ul>
//     <li>전공 : ${student.major}</li>
//     <li>학년 : ${student.grade}학년</li>
//     </ul>
//     `
//   });
//   document.querySelector("#result").innerHTML = output;
// })
// .catch(error => console.log(error));

// 0426 ~ 지금까지 배운 내용

// http 프로토콜

// 클라이언트 / 서버

// GET / POST 방식

// XMLHttpRequest

// XML => json 으로 대세가 바뀜 

// 제이슨 -> 객체 / 객체 -> 제이슨 으로 바꾸는 방법

// 예외처리방식 (try / catch / finally / throw)

// 비동기 프로그래밍
// (동기 처리방식 = 싱글스레드 => 콜백함수가 나옴
//   => 프로미스 객체가 나옴 => async 함수)

// 동기 처리방식 = 싱글스레드 / 비동기 처리방식 = 멀티스레드

// 콜백함수

// 프로미스 객체 => then / catch

// fetch (*XMLHttpRequest 의 업그레이드 버전)

// async 함수 / await 예약어
// > async 함수 와 await 예약어는 프로미스 객체 혹은 콜백함수 사용시, 함수안에 있는 실행문을 "비동기적"으로 실행하기 위해서 태어났습니다.



// 프로미스 객체
// function whatsYourFavorite() {
//   let fav = "Javascript";
//   return new Promise((resolve, reject) => resolve(fav))
// }

// function displaySubject(subject) {
//   return new Promise((resolve, reject) => resolve(`Hello, ${subject}`))
// }

// whatsYourFavorite()
//   .then(displaySubject)
//   .then(console.log)


// async 함수
// async function whatsYourFavorite() {
//   let fav = "Javascript";
//   return fav;
// }

// async function displaySubject(subject) {
//   return `Hello, ${subject}`
// }

// // whatsYourFavorite()
// //   .then(displaySubject)
// //   .then(console.log);

// async function init() {
//   const response = await whatsYourFavorite();
//   const result = await displaySubject(response);
//   console.log(result);
// }
// init();

// whatsYourFavorite() 함수의 실행이 끝날때까지 기다린 후에 response 값을 저장
// response값을 사용해서 displaySubject() 함수를 실행하고 결과값을 result저장
// await async함수 사용시 기다렸다 값을 받아야할 때가 있는데 그때 
// 비동기 처리방식중 동기방식이 필요할때 await를 사용한다