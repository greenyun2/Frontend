// *복습 0428
// 비동기 프로그래밍
// -동기처리방식 vs 비동기 처리 방식
// -비동기 처리 방식 콜백함수
// -익명으로 컬백함수 작성하기

// 프로미스 
// -프로미스 객체 만들기
// -프로미스 객체 사용하기
// -then() catch() finally() 메서드

// Fetch API 
// -프로미스를 반환하는 fetch

// async함수 await 예약어
// -async함수 
// -await예약어 (비동기 처리방식 안에서의 동기처리방식이 필요할때 사용)



// #### 비동기 프로그래밍 실습예제 
// ####회원정보 출력하기 만들기


// 외부데이터 가져올때 XHR 객체와 fetch 를 이용한다
// async function init() {
//   const response = await fetch("https://jsonplaceholder.typicode.com/users");
//   const users = await response.json();
//   display(users)
// }

// function display(users) {
//   const result = document.querySelector("#result");
//   let string = "";
//   users.forEach((user) => {
//     string += `
//       <table>
//       <tr>
//       <th>이름</th>
//       <td>${user.name}</td>
//       </tr>
//       <tr>
//       <th>아이디</th>
//       <td>${user.username}</td>
//       </tr>
//       <tr>
//       <th>이메일</th>
//       <td>${user.email}</td>
//       </tr>
//       </table>
//     `
//   });
//   result.innerHTML = string;
// }

// init();
// #### 외부 명언데이터 랜덤 출력하기
// const quoteURL = "https://dummyjson.com/quotes"

// fetch(quoteURL)
//   .then(response => response.json())
//   .then(data => {
//     const result = document.querySelector("#result");
//     const random = Math.floor(Math.random() * 30);
//     result.querySelector(".quote").innerHTML = data.quotes[random].quote
//     result.querySelector(".author").innerHTML = `- ${data.quotes[random].author} -`
//   })

// *캔버스 기능 => HTML5
// > 소스코드를 활용해서 그림을 그릴 수 있는 기능 부여!

// 캔버스를 쓰면 뭐가 좋은가? 
// > 자바스크립트를 활용해서 그림, 애니메이션 제작 및 생성!!

// *자바스크립트에서 캔버스 기능을 사용하려면
// 1) HTML 태그에서 <canvas>태그가 있어야 한다
// 2) 컨텍스트를 설정  => getContext()
// > 컨텍스트 개념 : 프로그램에 특정 실행문을 호출하고 응답받을 수 있는 준비를 해놓은 상태

// 캔버스를 전체화면으로 사용하기
// const canvas = document.querySelector("canvas");
// const ctx = canvas.getContext("2d");

// ctx.fillStyle = "rgb(200, 0, 0)";
// ctx.fillRect(10, 10, 50, 100);

// canvas.width = window.innerWidth;
// canvas.height = window.innerHeight;

// 일상생활에서 사용하는 각도 개념 degree
// 컴퓨터 프로그래밍 개발시, 사용하는 각도 개념 radian 

// 1 radian = 180도 / 파이(*원주율)
// 1 도 = 파이 / 180 

// 60도 만큼 움직이고 싶다 = (Math.PI / 180) * 60 

// 90도 = Math.PI * 0.5
// 180도 = Math.PI
// 270도 = Math.PI * 1.5
// 360도 = 0도 = Math.PI * 2    

// 역시계방향 -90도 = 270도 = Math.PI * 1.5

// *사각형을 그리는 메서드
// 1) fillRect (x, y, width, height) : 4가지의 인자값 : 색상을 채우는 사각형을 만들때
// 2) strokeRect (x, y, width, height) : 4가지의 인자값 : 테두리만 있는 사각형을 만들때
// 3) clearRect (x, y, width, height) : 특정 위치 및 사이즈의 사각영역을 지울 때

// 캔버스를 쓸때 *필수 설정
const canvas = document.querySelector("canvas");
const ctx = canvas.getContext("2d");

// #개구리
// ctx.scale(1, 0.8)

// #사각형
// // 사각형 색상을 채운다 빨간색으로
// ctx.fillStyle = "rgb(200, 0, 0)";
// // 사각형의 기본 색상은 검정
// ctx.fillRect(10, 10, 200, 100);
// // 스트로크 색상 블루
// ctx.strokeStyle = "blue";
// // 스트로크 기본 색상 검정
// ctx.strokeRect(10, 10, 200, 100);

// // 불투명도 opacity = rgba
// ctx.fillStyle = "rgba(0, 0, 200, 0.5)";
// ctx.fillRect(50, 50, 120, 100);

// // 가운데 삭생이 없는 사각형
// ctx.clearRect(70, 80, 80, 45);


// *삼각형을 그리는 메서드 : 사각형을 제외한 나머지 도형
// *사각형을 제외한 나머지 도형을 그리기 위한 필수 준비과정
// 1) beginPath() : 삼각형을 그리기 위한 준비신호 or 사각형을 제외한 나머지 도형
// 사각형을 제외한 나머지 도형은 기본이 아니다 그래서 다른 도형을 그릴때 써야한다

// 2) closePath() : 사각형을 제외한 나머지 도형을 다 그렸다는 마지막 신호

// 3) lineTo(x, y) : x축 y축 2가지 인자값,
// 시작점에서 부터 (x, y)좌표값까지 직선 경로를 만들겠다고 선언하는 메서드

// 4) moveTo(x, y) : 도형을 그릴 때, 시작점을 정의하는 메서드

// 5) strok() : 선에 대한 경로 설정 후 해당 메서드를 반드시 입력해야만 화면에 출력됩니다

// 6) fill() : 배경설정후 해당 메서드를 반드시 입력해야만 화면에 배경이 채워진다

// *원 및 호(와이파이의 수신모양)를 그리는 메서드
// 1) arc(x, y, r, startAngle, endAngle, counterClockwise)
// >6개의 인자값
// > x, y = 원의 중심 = 시작점
// > r : 원의 반지름 
// > startAngle : 시작이 될 radin 값
// > endAngle : 끝이 될 radin 값
// > counterClockwise : 반시계 방향으로 도는 것을 기본값으로 인식한다
// - true : 반시계 / false : 시계

// *타원을 그리는 메서드
// ellipse(x, y, radiusX, radiusY, rotaion, startAngle, endAngle, counterClockwise)
// > x, y : 타원의 중심
// > radiusX, radiusY : 타원의 가로 및 세로 반지름
// > rotaion : 타원의 회전 각도
// > startAngle : 시작이 될 radin 값
// > endAngle : 끝이 될 radin 값
// > counterClockwise : 반시계 방향으로 도는 것을 기본값으로 인식한다
// - true : 반시계 / false : 시계

// *타원을 그리는 두번째 방법
// - 기본적인 정원의 사이즈 변경을 통해서 가능
// - scale(x, y);

// * 곡선을 그리는 방법
// : 배지에 Bezier
// - 2차 배지에 곡선 (*조절점이 1개)
// > quardraticCurveTo(cpx, cpy, x, y)
// > cpx, cpy : 조절점 좌표
// > x, y : 곡선이 끝나는 좌표

// - 3차 배지에 곡선 (*조절점이 2개)
// > brzierCurveTo(cpx1, cpy1, cpx2, cpy2, x, y)

// * 캔버스 텍스트 그리기
// - fillText (text, x, y) 
// - strokeText (test, x, y)

// : text = 캔버스에 그릴 텍스트를 의미
// : x, y = 텍스트를 표시할 좌표

// * 켄버스에 이미지 표시하기
// - drawImage (image, dx, dy)
// - drawImage (image, sx, sy, sw, sh, dx, dy, dw, dh)
// > image : 캔버스에 표시할 이미지 객체 타입
// > dx, dy : 캔버스 좌측 상단으로 부터 얼마나 떨어진 지점에 표시할 것인가를 묻는 좌표값
// => 내장객체를 사용!!! 

// * 이미지 클리핑하기
//  - clip()



// #### 도형 예제!
// #사각형을 제외한 나머지 도형 그리기 준비과정
// ctx.beginPath();
// ctx.moveTo(50, 50);
// ctx.lineTo(200, 200);
// ctx.stroke()
// ctx.closePath(); // 생략가능!

// ctx.beginPath();
// ctx.moveTo(350, 50);
// ctx.lineTo(200, 200);
// ctx.strokeStyle = "red";
// ctx.stroke();
// ctx.closePath(); // 생략가능!

// #삼각형 그리기
// ctx.beginPath();
// ctx.moveTo(50, 50);
// ctx.lineTo(150, 100);
// ctx.lineTo(50, 150);
// ctx.closePath();
// ctx.stroke();

// ctx.beginPath();
// ctx.moveTo(150, 100);
// ctx.lineTo(250, 50);
// ctx.lineTo(250, 150);
// ctx.closePath();
// ctx.fillStyle = "rgb(0, 200, 0"
// ctx.fill();

// #원 그리기
// 스타일은 beginPath() 위쪽으로 써줘야한다
// ctx.strokeStyle = "red"
// ctx.fillStyle = "yellow"

// ctx.beginPath();
// ctx.arc(200, 150, 100, 0, Math.PI *2);
// ctx.stroke();
// ctx.fill();
// ctx.closePath();

// #반원 그리기
// ctx.fillStyle = "red"
// 반시계방향
// ctx.beginPath();
// ctx.arc(120, 100, 50, 0, Math.PI, true);
// ctx.fill();
// ctx.closePath();

// #시계방향
// ctx.beginPath();
// ctx.arc(280, 100, 50, 0, Math.PI, false);
// ctx.fill();
// ctx.closePath();

// #한꺼번에 쓰는 경우 (반시계, 시계)
// ctx.beginPath();
// ctx.arc(280, 100, 50, 0, Math.PI, false);
// ctx.arc(120, 100, 50, 0, Math.PI, true);
// ctx.fill();
// ctx.closePath();

// // #왼쪽 반원
// ctx.beginPath();
// ctx.arc(120, 200, 50, (Math.PI / 180) * 90, (Math.PI / 180) * 270, false);
// ctx.closePath();
// ctx.stroke();

// // #호 만들기
// ctx.strokeStyle = "blue"
// ctx.beginPath();
// ctx.arc(200, 200, 50, 0, (Math.PI / 180) * 60, false);
// ctx.stroke();

// #타원형 만들기
// ctx.strokeStyle = "red"
// ctx.beginPath();
// ctx.ellipse(200, 70, 80, 50, 0, 0, Math.PI * 2);
// ctx.closePath();
// ctx.stroke();

// ctx.strokeStyle = "blue"
// ctx.beginPath();
// ctx.ellipse(150, 200, 80, 50, (Math.PI / 180) * - 30, 0, Math.PI * 2);
// ctx.closePath();
// ctx.stroke();


// #타원형 만들기 방법 2 
// ctx.strokeStyle = "blue"
// ctx.scale(1, 0.7)

// ctx.beginPath();
// ctx.arc(200, 150, 80, 0, Math.PI * 2);
// ctx.closePath();
// ctx.stroke();

// ctx.beginPath();
// ctx.arc(200, 150, 30, 0, Math.PI * 2)
// ctx.closePath();
// ctx.stroke();

// #곡선 만들기 - 2차 배지에 곡선
// ctx.beginPath();
// ctx.moveTo(50, 200);
// ctx.quadraticCurveTo(200, 50, 350, 200)
// ctx.stroke();

// #곡선 만들기 - 2차 베지에 곡선 3개
// ctx.beginPath();
// ctx.moveTo(50, 100);
// ctx.quadraticCurveTo(100, 50, 150, 100);
// ctx.quadraticCurveTo(200, 150, 250, 100);
// ctx.quadraticCurveTo(300, 50, 350, 100);
// ctx.stroke();

// #곡선 만들기 - 3차 배지에 곡선
// ctx.strokeStyle = "green"
// ctx.beginPath();
// ctx.moveTo(50, 100);
// ctx.bezierCurveTo(140, 300, 310, 10, 350, 100);
// ctx.stroke();

// #인스턴스 객체 만들기
// let triangle = new Path2D();
// triangle.moveTo(100, 100);
// triangle.lineTo(300, 100);
// triangle.lineTo(200, 260);
// triangle.closePath();

// let circle = new Path2D();
// circle.arc(200, 155, 50, 0, Math.PI * 2);

// ctx.stroke(triangle);
// ctx.fillStyle = "green"
// ctx.fill(circle);

// #개구리 만들기
/* FACE */
// ctx.fillStyle = "green";
// ctx.strokeStyle = "black";
// ctx.beginPath();
// ctx.arc(150, 150, 80, 0, Math.PI * 2);
// ctx.fill();
// ctx.stroke();

// /* Eye */
// ctx.fillStyle = "white"
// ctx.strokeStyle = "green"
// ctx.beginPath();
// ctx.arc(120, 80, 20, 0, Math.PI * 2);
// ctx.moveTo(200, 80)
// ctx.arc(180, 80, 20, 0, Math.PI * 2);
// ctx.fill();
// ctx.stroke();

// ctx.fillStyle = "black"
// ctx.beginPath();
// ctx.arc(120, 80, 5, 0, Math.PI * 2);
// ctx.moveTo(200, 80)
// ctx.arc(180, 80, 5, 0, Math.PI * 2);
// ctx.fill();

// /* Mouse */
// ctx.strokeStyle = "black"
// ctx.lineWidth = 3;
// ctx.beginPath();
// ctx.arc(150, 150, 50, 0, Math.PI);
// ctx.stroke();

// * 캔버스 텍스트
// ctx.strokeStyle = "red"
// ctx.font = "italic 60px serif";
// ctx.strokeText("HELLO", 50, 70);

// ctx.fillStyle = "yellow"
// ctx.font = "bold 60px sans-serif";
// ctx.fillText("GOODBYE", 50, 150);

// *캔버스에 이미지 가져오기
// let img = new Image();
// 함수는 공식처럼 외우기
// img.onload = function() {
//   ctx.drawImage(img, 100, 50, 280, 350, 160, 100, 140, 175);
//   // ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
// }
// img.src = `/img/cat.jpg`

// * 이미지 클리핑하기
// let img = new Image();
// img.onload = function() {
//   ctx.drawImage(img, 0, 0, canvas.width, canvas.height)
// }

// img.src = `/img/bird.jpg`
// ctx.beginPath();
// ctx.arc(250, 120, 100, 0, Math.PI * 2);
// ctx.clip();

// * 별 그리기 
// ctx.fillStyle = "green"
// ctx.beginPath();
// ctx.moveTo(80, 100);
// ctx.lineTo(310, 100);
// ctx.lineTo(120, 250);
// ctx.lineTo(190, 30);
// ctx.lineTo(280, 250);
// ctx.lineTo(80, 100);
// ctx.closePath();

// ctx.fill();
// ctx.stroke();

// * 고양이 이미지 타원형 따기
// let cat = new Image();
// cat.onload = function() {
//   ctx.drawImage(cat, 0, 0, canvas.width, canvas.height)
// }

// cat.src = `/img/cat.jpg`

// ctx.beginPath();
// ctx.ellipse(200, 150, 100, 140, 0, 0, Math.PI * 2);
// ctx.clip();