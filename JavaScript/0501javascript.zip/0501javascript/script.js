// * 캔버스 그래픽 요소


// 캔버스에서 스타일을 지정하는 방법!!

// fillstyle = color;
// strokeStyle = color;

// 1# rgb / rgba / 16진수 / 색상이름

// 2# 그라데이션 : 복수의 컬러를 은은하게 사용하고자 할 때 사용하는 스타일 기법

// 1) 선형 그라데이션
// - createLinearGradinet(x1, y1, x2 y2);
// - 색 중지점 할당 메서드 : addColorStop(position, color);

// 2) 원형 그라데이션
// - createRadialGradinet(x1, y1, r1, x2, y2, r2);

// 3) 패턴 채우기 :
// - createPattern(image, type);

// 3# 그림자효과 추가하기

// 1) shadowOffsetX = X축으로부터 그림자가 얼마나 떨어져있는가;
// 2) shadowOffsetY = Y축으로부터 그림자가 얼마나 떨어져있는가;
// 3) shadowBlur = 그림자의 밝기 여부;
// 4) shadowColor = 그림자의 색상;

// 4# 텍스트 선 관련 스타일 속성 :
// 1) 선의 굵기 속성 : ctx.lineWidth = 값;
// 2) 선의 끝 모양 : ctx.lineCap = "butt" || "round" || 
// "square"(*선 양쪽 끝에 높이가 선 너비의 1/2인 사격형을 추가!);
// 3) 선 교차 스타일 : ctx.lineJoin = "bevel" || "miter" || "round";


// 실습예제 
// const canvas  = document.querySelector("canvas");
// const ctx = canvas.getContext("2d");

// canvas.width = window.innerWidth;
// canvas.height = window.innerHeight;


// 1# rgb / rgba / 16진수 / 색상이름
// 0에 가까워 지면 투명해짐 1로가면 불투명
// ctx.globalAlpha = 0.4; 모든 요소의 투명도
// ctx.fillStyle = "rgba(255, 0, 0, 0.2)";
// ctx.fillRect(50, 50, 100, 50);

// ctx.fillStyle = "rgba(0, 0, 255, 0.4)";
// ctx.fillRect(150, 50, 100, 50);

// ctx.fillStyle = "rgba(0, 255, 0, 0.8)";
// ctx.fillRect(250, 50, 100, 50);

// ctx.fillStyle = "rgba(255, 255, 0, 1)";
// ctx.fillRect(350, 50, 100, 50);


// 2# 그라데이션 : 복수의 컬러를 은은하게 사용하고자 할 때 사용하는 스타일 기법
// 1) 선형 그라데이션
// - createLinearGradinet(x1, y1, x2 y2);
// - 색 중지점 할당 메서드 : addColorStop(position, color);
// let linGrad = ctx.createLinearGradient(0, 0, 0, 200);
// linGrad.addColorStop(0, "#000");
// linGrad.addColorStop(0.6, "#fff");
// linGrad.addColorStop(1, "#eee");

// ctx.fillStyle = linGrad;
// ctx.fillRect(0, 0, 100, 200);


// 2) 원형 그라데이션
// - createRadialGradinet(x1, y1, r1, x2, y2, r2);

// let radGrad = ctx.createRadialGradient(55, 60, 10, 80, 90, 100);
// radGrad.addColorStop(0, "white");
// radGrad.addColorStop(0.4, "yellow");
// radGrad.addColorStop(1, "orange");

// ctx.fillStyle = radGrad;
// ctx.beginPath();
// ctx.arc(100, 100, 80, 0, Math.PI * 2, false);
// ctx.fill();

// 3) 패턴 채우기 :
// - createPattern(image, type);

// let img = new Image();
// img.onload = function() {
//   let pattern = ctx.createPattern(img, "repeat");
//   ctx.fillStyle = pattern;
//   ctx.fillRect(0, 0, 200, 200);
// };

// img.src = "img/pattern.png";

// 3# 그림자효과 추가하기

// let radGrad = ctx.createRadialGradient(55, 60, 10, 80, 90, 100)
// radGrad.addColorStop(0, "white");
// radGrad.addColorStop(0.4, "yellow");
// radGrad.addColorStop(1, "orange");

// ctx.shadowColor = "#ccc"
// // 1) shadowOffsetX = X축으로부터 그림자가 얼마나 떨어져있는가;
// ctx.shadowOffsetX = 15
// // 2) shadowOffsetY = Y축으로부터 그림자가 얼마나 떨어져있는가;
// ctx.shadowOffsetY = 20
// // 3) shadowBlur = 그림자의 밝기 여부;
// ctx.shadowBlur = 10

// ctx.fillStyle = radGrad;
// ctx.arc(100, 100, 80, 0, Math.PI * 2, false);
// ctx.fill();

// 4# 텍스트 선 관련 스타일 속성 :
//   // 2) 선의 끝 모양 : ctx.lineCap = "butt" || "round" || "square";
// const lineCap = ['butt', 'round', 'square'];

// ctx.strokeStyle = "#222";
// for (let i = 0; i < lineCap.length; i++) {
//   // 1) 선의 굵기 속성 : ctx.lineWidth = 값;
//   ctx.lineWidth = 15;
//   ctx.lineCap = lineCap[i];
//   ctx.beginPath();
//   ctx.moveTo(50, 50 + i * 30);
//   ctx.lineTo(350, 50 + i * 30);
//   ctx.stroke();
// }

// 3) 선 교차 스타일 : ctx.lineJoin = "bevel" || "miter" || "round";
// const lineJoin = ["bevel", "miter", "round"];

// for (let i = 0; i < lineJoin.length; i++) {
//   ctx.lineWidth = 20;
//   ctx.lineJoin = lineJoin[i];
//   ctx.beginPath();
//   ctx.moveTo(60, 60 * i + 50);
//   ctx.lineTo(100, 60 * i + 15);
//   ctx.lineTo(140, 60 * i + 50);
//   ctx.stroke();
// };

// #### 캔버스(그림판) 만들기 
// const canvas = document.querySelector("canvas");
// const toolbar = document.querySelector("#toolbar");
// const ctx = canvas.getContext("2d");

// canvas.width = window.innerWidth;
// canvas.height = window.innerHeight;

// const canvasOffsetX = canvas.offsetLeft;
// const canvasOffsetY = canvas.offsetTop;

// let isDrawing = false;
// let lineWidth = 2;

// canvas.addEventListener("mousedown", (e) => {
//   isDrawing = true;
// });

// canvas.addEventListener("mousemove", (e) => {
//   if (!isDrawing) return
//   ctx.lineWidth = lineWidth;
//   ctx.lineCap = "round";
//   ctx.lineTo(e.pageX - canvasOffsetX, e.pageY - canvasOffsetY);
//   ctx.stroke();
// });

// canvas.addEventListener("mouseup", (e) => {
//   isDrawing = false;
//   ctx.beginPath();
// });

// toolbar.addEventListener("change", (e) => {
//   // target = event가 실제 발생된 지점
//   if (e.target.id === "stroke") {
//     ctx.strokeStyle = e.target.value;
//   }
//   if (e.target.id === "lWidth") {
//     lineWidth = e.target.value;
//   }
// });

// toolbar.addEventListener("click", (e) => {
//   if(e.target.id === "reset") {
//     ctx.clearRect(0, 0, canvas.width, canvas.height);
//   }
// });
// target = event가 실제 발생된 지점


// 캔버스의 좌표설정 
// - translate(x, y) = 모든 좌표의 원점이 된다
// - save(), restore() = 좌표를 복구 시킬때 같이 쓴다. 해당 구간을 저장
// - save() 좌표 저장
// - restore() 여기 까지만

// ctx.fillStyle = "#ccc";
// ctx.fillRect(10, 10, 100, 100);

// ctx.save();
// ctx.translate(150, 150);
// ctx.fillStyle = "#222";
// ctx.fillRect(10, 10, 100, 100);
// ctx.fillStyle = "red";
// ctx.fillRect(50, 50, 80, 20);
// ctx.restore();

// ctx.fillStyle = "#f5f";
// ctx.fillRect(50, 100, 100, 100);

// ctx.fillStyle = "#ccc";
// ctx.fillRect(150, 150, 100, 100);

// ctx.translate(150, 150);
// ctx.rotate(Math.PI / 180 * 45);
// ctx.strokeRect(0, 0, 100, 100);
// ctx.translate(-150, -150)

// ctx.fillStyle = "#ccc";
// ctx.fillRect(150, 150, 100, 100);

// scale() 메서드 
// x, y = 3배수 ,2배수 좌표값까지 배로 먹는다
// ctx.fillStyle = "#ccc"
// ctx.fillRect(50, 50, 100, 50);

// ctx.save();
// ctx.scale(3, 2);
// ctx.strokeRect(20, 70, 100, 50);
// ctx.restore();

// ctx.strokeRect(200, 50, 100, 50);

// #### 회전시키기 만들기
// const canvas = document.querySelector('canvas');
// const ctx = canvas.getContext('2d');
// const btn = document.querySelector('button')
// const origin = {
//   x : window.innerWidth/2,
//   y : window.innerHeight/2
// };
// const alpha = 0.7;

// canvas.width = window.innerWidth;
// canvas.height = window.innerHeight;


// ctx.fillStyle = '#ccc';
// ctx.fillRect(origin.x, origin.y, 100, 100);

// btn.onclick = function rotateCtx() {
//   let color = randomRGB();
//   ctx.globalAlpha = alpha
//   ctx.translate(origin.x, origin.y);
//   ctx.rotate((Math.PI / 180) * 30);
//   ctx.fillStyle = color;
//   ctx.fillRect(0, 0, 100, 100);
//   ctx.translate(-origin.x, -origin.y);
// };

// function randomRGB() {
//   let red = Math.floor(Math.random() * 256);
//   let green = Math.floor(Math.random() * 256);
//   let blue = Math.floor(Math.random() * 256);

//   return `rgb(${red}, ${green}, ${blue})`;
// };


