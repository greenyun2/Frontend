// Bx Slider
$(document).ready(function(){
  $(".slider").bxSlider({
    mode: "horizontal",
    speed: "500",
    auto: true,
    pause: "3000",
    moveSlides: 2,
    autoHover: true,
    autoControls: true,
    pager: false,
  });
});


const openButton = document.querySelector('.open');
const container = document.querySelector('.container');
const closeButton = document.querySelector('.close');
const imgBtn = document.querySelector('.imgBtn');

const showMe = document.querySelector('.show');
const avenGers = document.querySelector('avengers')

openButton.addEventListener('click', () => {
  container.style.display = 'flex';
  openButton.style.display = 'none';
  openButton2.style.display = 'none';
});

closeButton.addEventListener('click', () => {
  container.style.display = 'none';
  openButton.style.display = 'block';
  openButton2.style.display = 'flex';
});

imgBtn.addEventListener('click', () => {
  openButton.style.display = 'block';
  container.style.display = 'none';
  openButton2.style.display = 'flex';
});

showMe.addEventListener('click', () => {
  container.style.display = 'none'
  openButton.style.display = 'block'
  openButton2.style.display = 'flex';
});

// Page 2
const openButton2 = document.querySelector('.open2');
const container2 = document.querySelector('.container2');
const closeButton2 = document.querySelector('.close2');
const imgBtn2 = document.querySelector('.imgBtn2');

openButton2.addEventListener('click', () => {
  container2.style.display = 'block';
  openButton2.style.display = 'none';
  openButton.style.display = 'none';

});

closeButton2.addEventListener('click', () => {
  container2.style.display = 'none';
  openButton2.style.display = 'block';
  openButton.style.display = 'block';
});

imgBtn2.addEventListener('click', () => {
  openButton2.style.display = 'block';
  openButton.style.display = 'block';
  container2.style.display = 'none';

});

