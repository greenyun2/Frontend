// Time
const hour = document.querySelector('.hour');
const min = document.querySelector('.min');
const sec = document.querySelector('.sec');

function clock() {
  const now = new Date();

  hour.innerText = now.getHours() + ('시');
  min.innerText = now.getMinutes() + ('분');
  sec.innerText = now.getSeconds() + ('초');
}

setInterval(clock, 1000);

// To Do List
const form = document.querySelector('form');
const input = document.querySelector('input');
const ul = document.querySelector('ul');

let todos = [];

const save = () => {
  localStorage.setItem('todos', JSON.stringify(todos));
}

const delItem = () => {
  const target = event.target.parentElement;
  todos = todos.filter((todo) => todo.id != target.id);
  save(); 
  target.remove();
}

const addItem = (todo) => {
  if(todo.text !== '') {
    const li = document.createElement('li');
    const button = document.createElement('button');
    const span = document.createElement('span');

    span.innerText = todo.text;
    button.innerText = '삭제';
    button.addEventListener('click', delItem)

    li.appendChild(span);
    li.appendChild(button);
    ul.appendChild(li);
    li.id = todo.id;
  }
}

const handler = (event) => {
  event.preventDefault();

  const todo = {
    id: Date.now(),
    text: input.value
    };

    todos.push(todo);
    addItem(todo);
    save();
    input.value='';
}

const init = () => {
  const userTodos = JSON.parse(localStorage.getItem('todos'));

  userTodos.array.forEach((todo) => {
    addItem(todo);
  });

  todos = userTodos;
}



form.addEventListener('submit', handler)

