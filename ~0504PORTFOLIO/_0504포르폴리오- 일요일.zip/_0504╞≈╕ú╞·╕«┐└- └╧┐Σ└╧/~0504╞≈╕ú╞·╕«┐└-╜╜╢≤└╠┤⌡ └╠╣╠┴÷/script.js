const frame = document.querySelector("section");
const lists = frame.querySelectorAll("article");
const deg = 45;
const len = lists.length-1;
let i = 0;

// Main Page Article
for(let el of lists) {
  // let pic = el.querySelector(".pic");
  el.style.transform = `rotate(${deg*i}deg) translateY(-100vh)`;
  i++;
};

/* 회전액션 */
const prev = document.querySelector(".btnPrev");
const next = document.querySelector(".btnNext");

let num = 0;

prev.addEventListener("click", () => {
  num++;
  frame.style.transform = `rotate(${deg*num}deg)`;

  (active == 0) ? active = len : active--;
  activation(active, lists)
})

next.addEventListener("click", () => {
  num--;
  frame.style.transform = `rotate(${deg*num}deg)`;

  (active == len) ? active = 0 : active++;
  activation(active, lists)
});

/* 가운데 있는 패널 활성화 */
let active = 0;

function activation(index, lists) {
  for(let el of lists) {
    el.classList.remove("on");
  }
  lists[index].classList.add("on");
};


// window.lode 이건가?
/* 모달 페이지 */
// 모달 창
const allPage = document.querySelector("#figure");
const background = document.querySelector("body")
const modalPage_1 = document.querySelector("#modalPage_1");
const modalPage_2 = document.querySelector("#modalPage_2");
const modalPage_3 = document.querySelector("#modalPage_3");
const modalPage_4 = document.querySelector("#modalPage_4");
// 버튼 역할
const aboutClick = document.querySelector("#aboutP");
const projectClick = document.querySelector("#projectP");
const resumeClick = document.querySelector("#resumeP");
const contactClick = document.querySelector("#contactP");
// 버튼 역할 2
const aboutClick_2 = document.querySelector("#aboutP_2");
const projectClick_2 = document.querySelector("#projectP_2");
const resumeClick_2 = document.querySelector("#resumeP_2");
const contactClick_2 = document.querySelector("#contactP_2");
// 나가기 버튼 역할
const backAbout = document.querySelector("#backAbout");
const backProject = document.querySelector("#backProject");
const backResume = document.querySelector("#backResume");
const backContact = document.querySelector("#backContact");

// About Page
aboutClick.addEventListener("click" , ()=> {
  modalPage_1.classList.add('show');
  allPage.classList.add('show')
  background.classList.add('show')
});

aboutClick_2.addEventListener("click" , ()=> {
  modalPage_1.classList.add('show');
  allPage.classList.add('show')
  background.classList.add('show')
});

backAbout.addEventListener("click", () => {
  modalPage_1.classList.remove('show');
  allPage.classList.remove('show')
});

// Project Page
projectClick.addEventListener("click" , ()=> {
  modalPage_2.classList.add('show');
  allPage.classList.add('show')
});

projectClick_2.addEventListener("click" , ()=> {
  modalPage_2.classList.add('show');
  allPage.classList.add('show')
});

backProject.addEventListener("click", () => {
  modalPage_2.classList.remove('show');
  allPage.classList.remove('show')
});
// // Resume Page
resumeClick.addEventListener("click" , ()=> {
  modalPage_3.classList.add('show');
  allPage.classList.add('show')
});

resumeClick_2.addEventListener("click" , ()=> {
  modalPage_3.classList.add('show');
  allPage.classList.add('show')
});

backResume.addEventListener("click", () => {
  modalPage_3.classList.remove('show');
  allPage.classList.remove('show')
});

// Contact Page
contactClick.addEventListener("click" , () =>  { 
  modalPage_4.classList.add('show');
  allPage.classList.add('show')
});

contactClick_2.addEventListener("click" , ()=> {
  modalPage_4.classList.add('show');
  allPage.classList.add('show');
});

backContact.addEventListener("click", () => {
  modalPage_4.classList.remove('show');
  allPage.classList.remove('show')
});



// Slider 

