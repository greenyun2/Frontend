// Slider 
const slides = document.querySelector(".slides");
const slide = document.querySelectorAll(".slides li");
const prevBtn = document.querySelector(".prev")
const nextBtn = document.querySelector(".next")
// 슬라이더의 위치파악
let currentIdx = 0;
// 슬라이더의 갯수 파악
let slideCount = slide.length;
// 슬라이더의 너비
let slideWidth = 200;
// 슬라이더의 간격
let slideMargin = 30;

makeClone();
// 복사본 만들기

function makeClone() {
  for(let i = 0; i < slideCount; i++) {
    // 기존의 li 태그들 뒤에 복제
    let cloneSlide = slide[i].cloneNode(true);
    //  원본과 복제품 구분하기 위한 클래스값 
    cloneSlide.classList.add("clone");
    // 기존의 내용 뒤에 복사본 생성
    slides.appendChild(cloneSlide);
  }
  for(let i = slideCount-1; i >= 0; i--) {
        // 기존의 li 태그들 뒤에 복제
        let cloneSlide = slide[i].cloneNode(true);
        //  원본과 복제품 구분하기 위한 클래스값 
        cloneSlide.classList.add("clone");
        // 요소의 앞에 내용을 복제
        slides.prepend(cloneSlide)
  }
  updateWidth();
  setInitialPos();
  
  setTimeout(function() {
    slides.classList.add(".animated")
  }, 100)
  
}

function updateWidth() {
  let newSlideCount = slide.length;
  let newWidth = (slideWidth + slideMargin) * newSlideCount - slideMargin + "px";
  slides.style.width = newWidth;
}
function setInitialPos() {
  let newSlideCount = slide.length;
  let initialTranslateValue = -(slideWidth + slideMargin) * newSlideCount;
  slides.style.transform = `translateX(${initialTranslateValue}px)`
}

nextBtn.addEventListener('click', function() {
  moveSlide(currentIdx + 1);
})
prevBtn.addEventListener('click', function() {
  moveSlide(currentIdx - 1);
})

function moveSlide(num) {
  slides.style.left = -num * (slideWidth + slideMargin) + "px"
  currentIdx = num
}