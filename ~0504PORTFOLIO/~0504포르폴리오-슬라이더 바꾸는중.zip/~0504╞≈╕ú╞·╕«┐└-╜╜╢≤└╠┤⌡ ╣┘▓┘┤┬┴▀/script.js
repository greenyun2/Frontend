const frame = document.querySelector("section");
const lists = frame.querySelectorAll("article");
const deg = 45;
const len = lists.length-1;
let i = 0;

const modalFrame = document.querySelector("#modal_section")
const modallists = frame.querySelectorAll("article");
const modallen = modallists.length-1;

// Main Page Article
for(let el of lists) {
  let pic = el.querySelector(".pic");
  el.style.transform = `rotate(${deg*i}deg) translateY(-100vh)`;
  // pic.style.backgroundImage = `url(/img/member${i+1}.jpg)`;
  i++;

  // let play = el.querySelector(".play");
  // let pause = el.querySelector('.pause');
  // let load = el.querySelector('.load');

  // play.addEventListener("click", e=>{
  //   e.currentTarget.closest("article").querySelector(".pic").classList.add("on");
  //   e.currentTarget.closest("article").querySelector("audio").play();
  // });

  // pause.addEventListener("click", e=> {
  //   e.currentTarget.closest("article").querySelector(".pic").classList.remove("on");
  //   e.currentTarget.closest("article").querySelector("audio").pause();
  // });

  // load.addEventListener("click", e=> {
  //   e.currentTarget.closest("article").querySelector(".pic").classList.add("on");
  //   e.currentTarget.closest("article").querySelector("audio").load();
  //   e.currentTarget.closest("article").querySelector("audio").play();
  // });
};
// 모달 슬라이더 역할
for(let el of modallists) {
  let pic = el.querySelector(".pic");
  el.style.transform = `rotate(${deg*i}deg) translateY(-100vh)`;
  // pic.style.backgroundImage = `url(/img/member${i+1}.jpg)`;
  i++;

  // let play = el.querySelector(".play");
  // let pause = el.querySelector('.pause');
  // let load = el.querySelector('.load');

  // play.addEventListener("click", e=>{
  //   e.currentTarget.closest("article").querySelector(".pic").classList.add("on");
  //   e.currentTarget.closest("article").querySelector("audio").play();
  // });

  // pause.addEventListener("click", e=> {
  //   e.currentTarget.closest("article").querySelector(".pic").classList.remove("on");
  //   e.currentTarget.closest("article").querySelector("audio").pause();
  // });

  // load.addEventListener("click", e=> {
  //   e.currentTarget.closest("article").querySelector(".pic").classList.add("on");
  //   e.currentTarget.closest("article").querySelector("audio").load();
  //   e.currentTarget.closest("article").querySelector("audio").play();
  // });
};

/* 회전액션 */
const prev = document.querySelector(".btnPrev");
const next = document.querySelector(".btnNext");

const modalPrev = document.querySelector(".modal_Prev");
const modalNext = document.querySelector(".modal_Next");
let num = 0;


prev.addEventListener("click", () => {
  num++;
  frame.style.transform = `rotate(${deg*num}deg)`;

  (active == 0) ? active = len : active--;
  activation(active, lists)
})

next.addEventListener("click", () => {
  num--;
  frame.style.transform = `rotate(${deg*num}deg)`;

  (active == len) ? active = 0 : active++;
  activation(active, lists)
});
// 모달 회전액션
modalPrev.addEventListener("click", () => {
  num++;
  modalFrame.style.transform = `rotate(${deg*num}deg)`;

  (active == 0) ? active = modallen : active--;
  activation(active, modallists)
})

modalNext.addEventListener("click", () => {
  num--;
  modalFrame.style.transform = `rotate(${deg*num}deg)`;

  (active == modallen) ? active = 0 : active++;
  activation(active, modallists)
});

/* 가운데 있는 패널 활성화 */
let active = 0;

function activation(index, lists) {
  for(let el of lists) {
    el.classList.remove("on");
  }
  lists[index].classList.add("on");
};

// location.reload() 문서로딩 이벤트 활용해야해
// window.lode 이건가?
/* 모달 페이지 */
// 모달 창
const allPage = document.querySelector("#figure");
const modalContainer = document.querySelector("#container");
const modalPage_1 = document.querySelector("#modalPage_1");
const modalPage_2 = document.querySelector("#modalPage_2");
const modalPage_3 = document.querySelector("#modalPage_3");
const modalPage_4 = document.querySelector("#modalPage_4");
// 버튼 역할
const aboutClick = document.querySelector("#aboutP");
const projectClick = document.querySelector("#projectP");
const resumeClick = document.querySelector("#resumeP");
const contactClick = document.querySelector("#contactP");
// 버튼 역할 2
const aboutClick_2 = document.querySelector("#aboutP_2");
const projectClick_2 = document.querySelector("#projectP_2");
const resumeClick_2 = document.querySelector("#resumeP_2");
const contactClick_2 = document.querySelector("#contactP_2");
// 나가기 버튼 역할
const backAbout = document.querySelector("#backAbout");
const backProject = document.querySelector("#backProject");
const backResume = document.querySelector("#backResume");
const backContact = document.querySelector("#backContact");

// About Page
aboutClick.addEventListener("click" , ()=> {
    allPage.style.display = "none"
    modalPage_1.style.display = "block"
    modalPage_2.style.display = "none"
    modalPage_3.style.display = "none"
    modalPage_4.style.display = "none"
});
aboutClick_2.addEventListener("click" , ()=> {
    allPage.style.display = "none"
    modalPage_1.style.display = "block"
    modalPage_2.style.display = "none"
    modalPage_3.style.display = "none"
    modalPage_4.style.display = "none"
});
backAbout.addEventListener("click", () => {
    allPage.style.display = "block"
    modalPage_1.style.display = "none"
    modalPage_2.style.display = "none"
    modalPage_3.style.display = "none"
    modalPage_4.style.display = "none"
});
// Project Page
projectClick.addEventListener("click" , ()=> {
    allPage.style.display = "none"
    modalPage_1.style.display = "none"
    modalPage_2.style.display = "inline-block"
    modalPage_3.style.display = "none"
    modalPage_4.style.display = "none"
});
projectClick_2.addEventListener("click" , ()=> {
    allPage.style.display = "none"
    modalPage_1.style.display = "none"
    modalPage_2.style.display = "block"
    modalPage_3.style.display = "none"
    modalPage_4.style.display = "none"
});
backProject.addEventListener("click", () => {
    allPage.style.display = "block"
    modalPage_1.style.display = "none"
    modalPage_2.style.display = "none"
    modalPage_3.style.display = "none"
    modalPage_4.style.display = "none"
});
// Resume Page
resumeClick.addEventListener("click" , ()=> {
    allPage.style.display = "none"
    modalPage_1.style.display = "none"
    modalPage_2.style.display = "none"
    modalPage_3.style.display = "block"
    modalPage_4.style.display = "none"
    
});
resumeClick_2.addEventListener("click" , ()=> {
    allPage.style.display = "none"
    modalPage_1.style.display = "none"
    modalPage_2.style.display = "none"
    modalPage_3.style.display = "block"
    modalPage_4.style.display = "none"
    
});
backResume.addEventListener("click", () => {
    allPage.style.display = "block"
    modalPage_1.style.display = "none"
    modalPage_2.style.display = "none"
    modalPage_3.style.display = "none"
    modalPage_4.style.display = "none"
});
// Contact Page
contactClick.addEventListener("click" , ()=> {
    allPage.style.display = "none"
    modalPage_1.style.display = "none"
    modalPage_2.style.display = "none"
    modalPage_3.style.display = "none"
    modalPage_4.style.display = "block"
    
});
contactClick_2.addEventListener("click" , ()=> {
    allPage.style.display = "none"
    modalPage_1.style.display = "none"
    modalPage_2.style.display = "none"
    modalPage_3.style.display = "none"
    modalPage_4.style.display = "block"
    
});
backContact.addEventListener("click", () => {
    allPage.style.display = "block"
    modalPage_1.style.display = "none"
    modalPage_2.style.display = "none"
    modalPage_3.style.display = "none"
    modalPage_4.style.display = "none"
});



// Slider 
// const slides = document.querySelector(".slides");
// const slide = document.querySelectorAll(".slides li");
// const prevBtn = document.querySelector(".modal-btnPrev")
// const nextBtn = document.querySelector(".modal-btnNext")
// // 슬라이더의 위치파악
// let currentIdx = 0;
// // 슬라이더의 갯수 파악
// let slideCount = slide.length;
// // 슬라이더의 너비
// let slideWidth = 990;
// // 슬라이더의 간격
// let slideMargin = 30;

// makeClone();
// // 복사본 만들기

// function makeClone() {
//   for(let i = 0; i < slideCount; i++) {
//     // 기존의 li 태그들 뒤에 복제
//     let cloneSlide = slide[i].cloneNode(true);
//     //  원본과 복제품 구분하기 위한 클래스값 
//     cloneSlide.classList.add("clone");
//     // 기존의 내용 뒤에 복사본 생성
//     slides.appendChild(cloneSlide);
//   }
//   for(let i = slideCount-1; i >= 0; i--) {
//         // 기존의 li 태그들 뒤에 복제
//         let cloneSlide = slide[i].cloneNode(true);
//         //  원본과 복제품 구분하기 위한 클래스값 
//         cloneSlide.classList.add("clone");
//         // 요소의 앞에 내용을 복제
//         slides.prepend(cloneSlide)
//   }
//   updateWidth();
//   setInitialPos();
  
//   setTimeout(function() {
//     slides.classList.add("animated")
//   }, 100)
  
// }

// function updateWidth() {
//   let currentSlides = document.querySelectorAll(".slides li");
//   let newSlideCount = currentSlides.length
//   let newWidth = (slideWidth + slideMargin) * newSlideCount - slideMargin + "px";
//   slides.style.width = newWidth;
// }

// function setInitialPos() {
//   let initialTranslateValue = -(slideWidth + slideMargin) * slideCount;
//   slides.style.transform = `translateX(${initialTranslateValue}px)`
// }

// nextBtn.addEventListener('click', function() {
//   moveSlide(currentIdx + 1);
// });

// prevBtn.addEventListener('click', function() {
//   moveSlide(currentIdx - 1);
// });

// function moveSlide(num) {
//   slides.style.left = -num * (slideWidth + slideMargin) + "px";
//   currentIdx = num
//   console.log(currentIdx, slideCount);

//   if(currentIdx == slideCount || currentIdx == -slideCount) {

//     setTimeout(function(){
//       slides.classList.remove(".animated")
//       slides.style.left = "0px";
//       currentIdx = 0;
//     }, 500);

//     setTimeout(function() {
//       slides.classList.add(".animated")
//     }, 600)
//   }
// }

