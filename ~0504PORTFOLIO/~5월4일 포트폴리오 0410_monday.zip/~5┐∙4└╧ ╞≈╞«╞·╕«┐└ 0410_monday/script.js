
window.addEventListener("wheel", function(e){
	e.preventDefault();
},{passive: false});

let html = document.querySelector("html");

html.scrollTo({top: 0, behavior:"smooth"});

let windowElement = window;
let htmlElement = document.querySelector('html');
let page = 1;
let lastPage = document.querySelectorAll('.content').length;
windowElement.addEventListener('wheel', function(e) {
  if(htmlElement.is(':animated')) return;
  if(e.deltaY >= 0) {
    if(page == lastPage) return;
    page++;
  } else if(e.deltaY <= 0) {
    if(page == 1) return;
    page--;
  }
  let posTop = (page - 1) * window.innerHeight;
  htmlElement.animate({ scrollTop: posTop });
});