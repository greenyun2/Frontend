const items = document.querySelectorAll("article");
const aside = document.querySelector("aside");
const close = aside.querySelector("span");

for(let el of items) {
  el.addEventListener("mouseenter", e=>{
    e.currentTarget.querySelector("video").play();
  });
  el.addEventListener("mouseleave", e=>{
    e.currentTarget.querySelector("video").paused();
  });

  el.addEventListener("click", e=>{
    let tit = e.currentTarget.querySelector("h2").innerText;
    let txt = e.currentTarget.querySelector("p").innerText;
    let vidSrc = e.currentTarget.querySelector("video").getAttribute("src");
  
  aside.querySelector("h1").innerText = tit;
  aside.querySelector("p").innerText = txt;
  aside.querySelector("video").setAttribute("src", vidSrc);

  aside.querySelector("video").play();
  // 클릭시 화면 튀어나오는 기능
  aside.classList.add("on");
  });

  close.addEventListener("click", ()=> {
    // close 클릭시 다시 사라지는 기능
    aside.classList.remove("on");
    aside.querySelector("video").pause();
  });
}