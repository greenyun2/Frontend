const frame = document.querySelector("section");
const lists = frame.querySelectorAll("article");
const deg = 45;
const len = lists.length-1;
let i = 0;

// Main Page Article
for(let el of lists) {
  let pic = el.querySelector(".pic");
  el.style.transform = `rotate(${deg*i}deg) translateY(-100vh)`;
  // pic.style.backgroundImage = `url(/img/member${i+1}.jpg)`;
  i++;

  // let play = el.querySelector(".play");
  // let pause = el.querySelector('.pause');
  // let load = el.querySelector('.load');

  // play.addEventListener("click", e=>{
  //   e.currentTarget.closest("article").querySelector(".pic").classList.add("on");
  //   e.currentTarget.closest("article").querySelector("audio").play();
  // });

  // pause.addEventListener("click", e=> {
  //   e.currentTarget.closest("article").querySelector(".pic").classList.remove("on");
  //   e.currentTarget.closest("article").querySelector("audio").pause();
  // });

  // load.addEventListener("click", e=> {
  //   e.currentTarget.closest("article").querySelector(".pic").classList.add("on");
  //   e.currentTarget.closest("article").querySelector("audio").load();
  //   e.currentTarget.closest("article").querySelector("audio").play();
  // });

};

/* 회전액션 */
const prev = document.querySelector(".btnPrev");
const next = document.querySelector(".btnNext");

let num = 0;

prev.addEventListener("click", () => {
  num++;
  frame.style.transform = `rotate(${deg*num}deg)`;

  (active == 0) ? active = len : active--;
  activation(active, lists)
})

next.addEventListener("click", () => {
  num--;
  frame.style.transform = `rotate(${deg*num}deg)`;

  (active == len) ? active = 0 : active++;
  activation(active, lists)
});

/* 가운데 있는 패널 활성화 */
let active = 0;

function activation(index, lists) {
  for(let el of lists) {
    el.classList.remove("on");
  }
  lists[index].classList.add("on");
};

// location.reload() 문서로딩 이벤트 활용해야해
// window.lode 이건가?
/* 모달 페이지 */
// 모달 창
const allPage = document.querySelector("#figure");
const modalContainer = document.querySelector("#container");
const modalPage_1 = document.querySelector("#modalPage_1");
const modalPage_2 = document.querySelector("#modalPage_2");
const modalPage_3 = document.querySelector("#modalPage_3");
const modalPage_4 = document.querySelector("#modalPage_4");
// 버튼 역할
const aboutClick = document.querySelector("#aboutP");
const projectClick = document.querySelector("#projectP");
const resumeClick = document.querySelector("#resumeP");
const contactClick = document.querySelector("#contactP");
// 버튼 역할 2
const aboutClick_2 = document.querySelector("#aboutP_2");
const projectClick_2 = document.querySelector("#projectP_2");
const resumeClick_2 = document.querySelector("#resumeP_2");
const contactClick_2 = document.querySelector("#contactP_2");
// 나가기 버튼 역할
const backAbout = document.querySelector("#backAbout");
const backProject = document.querySelector("#backProject");
const backResume = document.querySelector("#backResume");
const backContact = document.querySelector("#backContact");

// About Page
aboutClick.addEventListener("click" , ()=> {
    allPage.style.display = "none"
    modalPage_1.style.display = "block"
    modalPage_2.style.display = "none"
    modalPage_3.style.display = "none"
    modalPage_4.style.display = "none"
});
aboutClick_2.addEventListener("click" , ()=> {
    allPage.style.display = "none"
    modalPage_1.style.display = "block"
    modalPage_2.style.display = "none"
    modalPage_3.style.display = "none"
    modalPage_4.style.display = "none"
});
backAbout.addEventListener("click", () => {
    allPage.style.display = "block"
    modalPage_1.style.display = "none"
    modalPage_2.style.display = "none"
    modalPage_3.style.display = "none"
    modalPage_4.style.display = "none"
});
// Project Page
projectClick.addEventListener("click" , ()=> {
    allPage.style.display = "none"
    modalPage_1.style.display = "none"
    modalPage_2.style.display = "block"
    modalPage_3.style.display = "none"
    modalPage_4.style.display = "none"
});
projectClick_2.addEventListener("click" , ()=> {
    allPage.style.display = "none"
    modalPage_1.style.display = "none"
    modalPage_2.style.display = "block"
    modalPage_3.style.display = "none"
    modalPage_4.style.display = "none"
});
backProject.addEventListener("click", () => {
    allPage.style.display = "block"
    modalPage_1.style.display = "none"
    modalPage_2.style.display = "none"
    modalPage_3.style.display = "none"
    modalPage_4.style.display = "none"
});
// Resume Page
resumeClick.addEventListener("click" , ()=> {
    allPage.style.display = "none"
    modalPage_1.style.display = "none"
    modalPage_2.style.display = "none"
    modalPage_3.style.display = "block"
    modalPage_4.style.display = "none"
    
});
resumeClick_2.addEventListener("click" , ()=> {
    allPage.style.display = "none"
    modalPage_1.style.display = "none"
    modalPage_2.style.display = "none"
    modalPage_3.style.display = "block"
    modalPage_4.style.display = "none"
    
});
backResume.addEventListener("click", () => {
    allPage.style.display = "block"
    modalPage_1.style.display = "none"
    modalPage_2.style.display = "none"
    modalPage_3.style.display = "none"
    modalPage_4.style.display = "none"
});
// Contact Page
contactClick.addEventListener("click" , ()=> {
    allPage.style.display = "none"
    modalPage_1.style.display = "none"
    modalPage_2.style.display = "none"
    modalPage_3.style.display = "none"
    modalPage_4.style.display = "block"
    
});
contactClick_2.addEventListener("click" , ()=> {
    allPage.style.display = "none"
    modalPage_1.style.display = "none"
    modalPage_2.style.display = "none"
    modalPage_3.style.display = "none"
    modalPage_4.style.display = "block"
    
});
backContact.addEventListener("click", () => {
    allPage.style.display = "block"
    modalPage_1.style.display = "none"
    modalPage_2.style.display = "none"
    modalPage_3.style.display = "none"
    modalPage_4.style.display = "none"
});



// Slider 정의
const modalFrame = document.querySelector("#modalSection");
const modalLists = modalFrame.querySelectorAll("#modalArti");
const modalLen = modalLists.length-1;
// button 정의
const modalBtnPrev = document.querySelector(".modal-btnPrev");
const modalBtnNext = document.querySelector(".modal-btnNext");

let num1 = 0;

modalBtnPrev.addEventListener("click", () => {
  num1--;
  modalFrame.style.transform = `translateX(${-num1 * 100}%)`;

  (active == 0) ? active = modalLen : active--;
  activation(active, modalLists)
});

modalBtnNext.addEventListener("click", () => {
  num1++;
  modalFrame.style.transform = `translateX(${-num1 * 100}%)`;

  (active == 0) ? active = modalLen : active--;
  activation(active, modalLists)
})